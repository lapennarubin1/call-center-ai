-- 017_disable_unconfigured_managed_provider.sql
-- Correccion HISTORICA de 016 (que no se edita — politica de migraciones
-- inmutables: una vez aplicada, se corrige hacia adelante, nunca in-place).
--
-- Por que existe esta migracion:
-- 016 sembro la cuenta managed compartida de ElevenLabs con status='active'.
-- Eso es incorrecto: voice_catalog.resolve_provider_account() usa
-- status='active' como señal de "esta cuenta esta lista para resolver
-- operaciones remotas del proveedor". secret_ref='PLATFORM_ELEVENLABS_KEY'
-- es solo el NOMBRE de una variable de entorno — en el momento en que 016
-- se aplico no habia ningun valor real detras de esa variable, asi que
-- 'active' afirmaba una capacidad que la fila no tenia todavia.
--
-- Por que se mantiene 016 tal cual (con 'active') en vez de reescribirla:
-- 016 ya fue aplicada en produccion — es un hecho historico. Editar una
-- migracion ya aplicada rompe la garantia de que el archivo en el repo
-- coincide con lo que realmente se ejecuto en cada ambiente, y en
-- entornos donde 016 todavia no corrio, cambiar su contenido cambiaria
-- silenciosamente el comportamiento de una migracion cuyo checksum/orden
-- ya podria estar referenciado en otro lado. La correccion se hace SIEMPRE
-- hacia adelante, con una migracion nueva — este archivo.
--
-- Consistencia entre instalaciones nuevas y existentes:
-- en una instalacion NUEVA (desde cero), el sistema de migraciones aplica
-- 001..017 en orden dentro de la MISMA corrida — 016 deja la fila en
-- 'active' por una fraccion de segundo, y 017 la corrige a 'disabled'
-- antes de que la aplicacion arranque a servir trafico. El resultado
-- final es identico al de produccion (que se corrigio manualmente):
-- 'disabled'. No hay ninguna ventana real donde la fila quede utilizable
-- con 'active' en un sistema en funcionamiento.
--
-- Alcance ESTRICTO de este UPDATE:
--   - SOLO la fila managed compartida de elevenlabs (tenant_id IS NULL).
--   - NUNCA toca filas BYOK (tenant_id NOT NULL) de ningun tenant.
--   - NUNCA toca cuentas de otros provider_key.
--   - NO crea ninguna fila nueva (a proposito: si por algun motivo la fila
--     de 016 no existe todavia en un ambiente dado, este UPDATE
--     simplemente no afecta ninguna fila — no es su responsabilidad
--     sembrar datos, eso ya lo hizo 016).
--   - NO modifica secret_ref, tenant_id, provider_key, account_type,
--     display_name ni ninguna otra columna — solo status.
--
-- Idempotente: el filtro "AND status != 'disabled'" hace que correr esta
-- migracion mas de una vez, o sobre una fila que un operador ya corrigio
-- a mano (como paso en produccion), nunca falle y nunca escriba de mas.

UPDATE ai_provider_accounts
SET status = 'disabled'
WHERE provider_key = 'elevenlabs'
  AND account_type = 'managed'
  AND tenant_id IS NULL
  AND status != 'disabled';
