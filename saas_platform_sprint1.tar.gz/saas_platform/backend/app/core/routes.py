"""Rutas core: salud y catalogos. /health es el criterio de aceptacion SP-11:
confirma ambas conexiones y devuelve 503 si alguna falla."""
from flask import Blueprint, jsonify, g
from sqlalchemy import text
from .. import db
from .registry import module_manifests
from .auth.rbac import requires_role

bp = Blueprint("core", __name__, url_prefix="/api/v1")


@bp.get("/health")
def health():
    ok1, m1 = db.ping(db.saas_engine)
    ok2, m2 = db.ping(db.asterisk_ro_engine)
    status = 200 if (ok1 and ok2) else 503
    return jsonify(status="ok" if status == 200 else "degraded",
                   saas_platform={"ok": ok1, "detail": m1},
                   asterisk_readonly={"ok": ok2, "detail": m2},
                   modules=[m["key"] for m in module_manifests()]), status


@bp.get("/modules")
@requires_role("admin", "owner")
def modules():
    with db.saas_session() as s:
        enabled = {r[0]: r[1] for r in s.execute(text(
            "SELECT module_key, status FROM tenant_modules WHERE tenant_id=:t"), {"t": g.tenant_id})}
    out = []
    for m in module_manifests():
        out.append({**m, "tenant_status": enabled.get(m["key"], "not_enabled")})
    return jsonify(items=out)


@bp.get("/catalog/services")
@requires_role("admin", "owner")
def catalog_services():
    with db.saas_session() as s:
        rows = s.execute(text("SELECT service_key, name, unit, module_key, status FROM billable_services ORDER BY 1")).mappings().all()
    return jsonify(items=[dict(r) for r in rows])


@bp.get("/catalog/integrations")
@requires_role("admin", "owner")
def catalog_integrations():
    with db.saas_session() as s:
        rows = s.execute(text(
            "SELECT provider_key, name, category, auth_type, status FROM integration_providers ORDER BY category, name")).mappings().all()
    return jsonify(items=[dict(r) for r in rows])
