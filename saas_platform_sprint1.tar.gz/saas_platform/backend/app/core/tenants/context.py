"""TenantContextService (Documento 11, 2.2).
Fija el tenant activo en flask.g a partir de la SESION del servidor.
El tenant_id NUNCA viene del cliente (body, query param, header)."""
from flask import g, session, abort


def load_tenant_context():
    g.user_id = session.get("user_id")
    g.tenant_id = session.get("tenant_id")
    g.role = session.get("role")


def require_tenant() -> int:
    """Devuelve el tenant_id de la sesion o corta con 401."""
    if not getattr(g, "tenant_id", None):
        abort(401, description="No autenticado")
    return g.tenant_id
