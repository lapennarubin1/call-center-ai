"""AuthService (Documento 11, 2.3): login contra users.password_hash.
Sin fallback a variables de entorno: este backend es nuevo, no hereda el
login del panel actual (que sigue intacto en landmark-panel)."""
from datetime import datetime
from flask import Blueprint, request, session, jsonify, g
from sqlalchemy import text
from werkzeug.security import check_password_hash
from ...db import saas_session
from ..tenants.context import require_tenant

bp = Blueprint("auth", __name__, url_prefix="/api/v1/auth")


@bp.post("/login")
def login():
    data = request.get_json(silent=True) or {}
    tenant_slug = (data.get("tenant") or "").strip()
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""
    if not (tenant_slug and username and password):
        return jsonify(error="tenant, username y password son requeridos"), 400

    with saas_session() as s:
        row = s.execute(text("""
            SELECT u.id, u.tenant_id, u.role, u.password_hash, u.status AS user_status, t.status AS tenant_status
            FROM users u JOIN tenants t ON t.id = u.tenant_id
            WHERE t.slug = :slug AND u.username = :username
        """), {"slug": tenant_slug, "username": username}).mappings().first()

        if not row or not check_password_hash(row["password_hash"], password):
            return jsonify(error="Credenciales invalidas"), 401
        if row["user_status"] != "active" or row["tenant_status"] == "suspended":
            return jsonify(error="Usuario o tenant inactivo"), 403

        s.execute(text("UPDATE users SET last_login_at=:now WHERE id=:id"), {"now": datetime.utcnow(), "id": row["id"]})

    session.clear()
    session["user_id"] = row["id"]
    session["tenant_id"] = row["tenant_id"]
    session["role"] = row["role"]
    return jsonify(ok=True, tenant_id=row["tenant_id"], role=row["role"])


@bp.post("/logout")
def logout():
    session.clear()
    return jsonify(ok=True)


@bp.get("/me")
def me():
    tid = require_tenant()
    with saas_session() as s:
        t = s.execute(text("SELECT id, slug, name, status FROM tenants WHERE id=:t"), {"t": tid}).mappings().first()
        mods = [r[0] for r in s.execute(text(
            "SELECT module_key FROM tenant_modules WHERE tenant_id=:t AND status='enabled' ORDER BY module_key"), {"t": tid})]
    return jsonify(user_id=g.user_id, role=g.role, tenant=dict(t), modules=mods)
