"""RBACService (Documento 11, 2.4). Roles del ENUM users.role.
Un modulo no habilitado en tenant_modules => 403, sin importar el rol."""
from functools import wraps
from flask import g, abort
from sqlalchemy import text
from ..tenants.context import require_tenant
from ...db import saas_session

ROLE_RANK = {"viewer": 1, "support": 1, "operator": 2, "admin": 3, "owner": 4, "superadmin": 5}


def requires_role(*allowed):
    def deco(fn):
        @wraps(fn)
        def wrapper(*a, **kw):
            require_tenant()
            if g.role not in allowed and g.role != "superadmin":
                abort(403, description="Rol sin permiso para esta accion")
            return fn(*a, **kw)
        return wrapper
    return deco


def requires_module(module_key: str):
    def deco(fn):
        @wraps(fn)
        def wrapper(*a, **kw):
            tid = require_tenant()
            with saas_session() as s:
                row = s.execute(text(
                    "SELECT 1 FROM tenant_modules WHERE tenant_id=:t AND module_key=:m AND status='enabled'"
                ), {"t": tid, "m": module_key}).first()
            if not row:
                abort(403, description=f"Modulo '{module_key}' no habilitado para este tenant")
            return fn(*a, **kw)
        return wrapper
    return deco
