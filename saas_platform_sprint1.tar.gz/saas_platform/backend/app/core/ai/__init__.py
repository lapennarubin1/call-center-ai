"""Gateway de IA (Documento 15, 2.1). Sprint 1: solo el contrato.
Todo modulo que necesite un LLM/voz pasara por aqui para que el core cuente
tokens (ai_tokens_in/out via metering) y aplique la clave del tenant.
Implementacion real: cuando arranque el primer canal (Fase B / M3)."""
