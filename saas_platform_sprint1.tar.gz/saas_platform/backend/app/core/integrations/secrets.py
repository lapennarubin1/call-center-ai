"""IntegrationsService (Documento 11, 2.2 / 5.3): config_ref -> valor.
Sprint 1: variables de entorno con convencion TENANT_<id>_<PROVIDER>_KEY.
El valor NUNCA se devuelve al frontend ni se escribe en logs."""
import os


def resolve_secret(config_ref: str) -> str | None:
    return os.getenv(config_ref)
