"""Marketplace de integraciones (Documento 15, 5). Sprint 1: catalogo en BD
(integration_providers) + instancias por tenant (tenant_integrations).
La resolucion de config_ref -> secreto real vive en secrets.py."""
