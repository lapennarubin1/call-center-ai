"""Bus de eventos de dominio (Documento 15, 2.3). Patron outbox:
los modulos PUBLICAN; los consumidores llegan en fases posteriores."""
import json
from sqlalchemy import text


def publish(session, tenant_id: int, module_key: str, event_type: str,
            aggregate_type: str | None = None, aggregate_id: int | None = None, payload: dict | None = None):
    session.execute(text("""
        INSERT INTO domain_events (tenant_id, module_key, event_type, aggregate_type, aggregate_id, payload)
        VALUES (:t, :m, :e, :at, :aid, :p)
    """), {"t": tenant_id, "m": module_key, "e": event_type, "at": aggregate_type, "aid": aggregate_id,
           "p": json.dumps(payload or {})})
