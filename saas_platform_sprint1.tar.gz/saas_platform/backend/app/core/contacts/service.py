"""Identidad unificada (Documento 15, 3.2). find_or_create por telefono/email
normalizado DENTRO del tenant. Publica contact.created en el outbox."""
import re
from sqlalchemy import text
from ..events.outbox import publish


def normalize_phone(raw: str | None) -> str | None:
    if not raw:
        return None
    digits = re.sub(r"[^\d+]", "", raw)
    if digits and not digits.startswith("+"):
        digits = "+" + digits
    return digits or None


def find_or_create(session, tenant_id: int, full_name=None, phone=None, email=None, country=None) -> tuple[int, bool]:
    phone_n = normalize_phone(phone)
    email_n = email.strip().lower() if email else None
    if phone_n:
        row = session.execute(text("SELECT id FROM contacts WHERE tenant_id=:t AND phone_e164=:p LIMIT 1"),
                              {"t": tenant_id, "p": phone_n}).first()
        if row:
            return row[0], False
    if email_n:
        row = session.execute(text("SELECT id FROM contacts WHERE tenant_id=:t AND email=:e LIMIT 1"),
                              {"t": tenant_id, "e": email_n}).first()
        if row:
            return row[0], False
    res = session.execute(text("""
        INSERT INTO contacts (tenant_id, full_name, phone_e164, email, country) VALUES (:t, :n, :p, :e, :c)
    """), {"t": tenant_id, "n": full_name, "p": phone_n, "e": email_n, "c": country})
    cid = res.lastrowid
    publish(session, tenant_id, "core", "contact.created", "contact", cid, {"phone": phone_n, "email": email_n})
    return cid, True
