"""Registro de modulos (Documento 15, 2.2). Cada modulo declara un manifiesto;
el core no tiene una lista hardcodeada de modulos en las rutas."""
MODULES: dict[str, dict] = {}


def register_module(manifest: dict):
    key = manifest["key"]
    if key in MODULES:
        raise RuntimeError(f"Modulo duplicado: {key}")
    MODULES[key] = manifest


def module_manifests() -> list[dict]:
    return [{k: v for k, v in m.items() if k != "blueprint"} for m in MODULES.values()]
