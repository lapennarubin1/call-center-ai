"""Metering API (Documento 15, 4.1). UNICA via para registrar consumo.
Idempotente por (tenant_id, service_key, reference_id): el UNIQUE en BD
garantiza que un mismo cdr.uniqueid nunca se cobra dos veces."""
import json
from decimal import Decimal
from datetime import datetime
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError


def record_usage(session, tenant_id: int, service_key: str, quantity, reference_id: str,
                 occurred_at: datetime | None = None, cost_usd=0, price_usd=None, metadata: dict | None = None) -> bool:
    """Devuelve True si se registro, False si ya existia (duplicado ignorado)."""
    if price_usd is None:
        price_usd = _price_for(session, tenant_id, service_key, quantity)
    try:
        with session.begin_nested():
            session.execute(text("""
                INSERT INTO usage_events (tenant_id, service_key, quantity, cost_usd, price_usd, reference_id, occurred_at, metadata)
                VALUES (:t, :s, :q, :c, :p, :r, :o, :m)
            """), {"t": tenant_id, "s": service_key, "q": Decimal(str(quantity)), "c": Decimal(str(cost_usd)),
                   "p": Decimal(str(price_usd)), "r": reference_id, "o": occurred_at or datetime.utcnow(),
                   "m": json.dumps(metadata or {})})
        return True
    except IntegrityError:
        return False


def _price_for(session, tenant_id: int, service_key: str, quantity) -> Decimal:
    """Precio segun el plan activo del tenant. Sprint 1: solo excedente plano
    (overage_price_usd * quantity); el descuento de included_quantity por
    periodo llega con usage_period_summaries (fase posterior)."""
    row = session.execute(text("""
        SELECT pe.overage_price_usd FROM tenants t
        JOIN plan_entitlements pe ON pe.plan_id = t.plan_id AND pe.service_key = :s
        WHERE t.id = :t
    """), {"t": tenant_id, "s": service_key}).first()
    return (Decimal(str(row[0])) * Decimal(str(quantity))) if row else Decimal("0")
