from .routes import bp

MANIFEST = {
    "key": "crm",
    "name": "CRM / Leads",
    "emits_services": [],
    "publishes_events": ["crm.lead.created"],
    "consumes_events": ["contact.created"],
    "blueprint": bp,
}
