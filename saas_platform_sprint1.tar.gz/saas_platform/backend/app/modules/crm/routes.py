"""Modulo crm — Sprint 1: listar leads y alta manual (Modelo A, CRM interno).
La alta pasa por core/contacts (identidad unificada) y publica un evento."""
from flask import Blueprint, jsonify, request, g
from sqlalchemy import text
from ...db import saas_session
from ...core.auth.rbac import requires_role, requires_module
from ...core.contacts.service import find_or_create
from ...core.events.outbox import publish

bp = Blueprint("crm", __name__, url_prefix="/api/v1/crm")


@bp.get("/leads")
@requires_module("crm")
@requires_role("viewer", "operator", "admin", "owner")
def list_leads():
    with saas_session() as s:
        rows = s.execute(text("""
            SELECT l.id, l.status, l.stage, l.external_id, l.created_at,
                   c.id AS contact_id, c.full_name, c.phone_e164, c.email
            FROM crm_leads l JOIN contacts c ON c.id = l.contact_id
            WHERE l.tenant_id=:t ORDER BY l.id DESC LIMIT 200
        """), {"t": g.tenant_id}).mappings().all()
    return jsonify(items=[dict(r) for r in rows])


@bp.post("/leads")
@requires_module("crm")
@requires_role("operator", "admin", "owner")
def create_lead():
    d = request.get_json(silent=True) or {}
    if not (d.get("phone") or d.get("email")):
        return jsonify(error="phone o email requerido"), 400
    with saas_session() as s:
        contact_id, created = find_or_create(s, g.tenant_id, d.get("full_name"), d.get("phone"), d.get("email"), d.get("country"))
        res = s.execute(text("""
            INSERT INTO crm_leads (tenant_id, contact_id, source_id, external_id, status, stage)
            VALUES (:t, :c, NULL, :ext, 'new', :stage)
        """), {"t": g.tenant_id, "c": contact_id, "ext": d.get("external_id"), "stage": d.get("stage")})
        lead_id = res.lastrowid
        publish(s, g.tenant_id, "crm", "crm.lead.created", "crm_lead", lead_id, {"contact_id": contact_id})
    return jsonify(id=lead_id, contact_id=contact_id, contact_created=created), 201
