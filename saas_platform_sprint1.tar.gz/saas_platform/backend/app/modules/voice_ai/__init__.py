from .routes import bp

MANIFEST = {
    "key": "voice_ai",
    "name": "Voice AI Call Center",
    "emits_services": ["voice_minutes"],
    "publishes_events": ["voice.call.completed"],
    "consumes_events": [],
    "blueprint": bp,
}
