"""Dos engines, dos usuarios, dos permisos distintos.
- saas_engine: saas_platform, lectura/escritura (saas_rw)
- asterisk_ro_engine: asterisk, SOLO lectura (saas_ro_asterisk). El permiso lo
  impone MariaDB (GRANT SELECT); este modulo solo expone la conexion."""
from contextlib import contextmanager
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

saas_engine = None
asterisk_ro_engine = None
SaasSession = None


def init_db(app):
    global saas_engine, asterisk_ro_engine, SaasSession
    saas_engine = create_engine(app.config["SAAS_DB_URL"], pool_pre_ping=True, pool_recycle=1800, future=True)
    asterisk_ro_engine = create_engine(app.config["ASTERISK_RO_DB_URL"], pool_pre_ping=True, pool_recycle=1800, future=True)
    SaasSession = sessionmaker(bind=saas_engine, future=True, expire_on_commit=False)


@contextmanager
def saas_session():
    """Sesion transaccional sobre saas_platform."""
    s = SaasSession()
    try:
        yield s
        s.commit()
    except Exception:
        s.rollback()
        raise
    finally:
        s.close()


def ping(engine) -> tuple[bool, str]:
    try:
        with engine.connect() as c:
            c.execute(text("SELECT 1"))
        return True, "ok"
    except Exception as e:  # noqa: BLE001
        return False, str(e).split("\n")[0][:200]
