"""Configuracion central. Todo viene de variables de entorno (backend/.env).
Ningun valor sensible vive en codigo."""
import os
from dotenv import load_dotenv

load_dotenv()  # carga backend/.env si existe (en Docker las vars ya vienen del entorno)


def _env(name: str, default: str | None = None, required: bool = False) -> str:
    val = os.getenv(name, default)
    if required and not val:
        raise RuntimeError(f"Variable de entorno requerida no definida: {name}")
    return val


class Config:
    ENV = _env("SAAS_ENV", "production")
    SECRET_KEY = _env("SAAS_SECRET_KEY", required=True)
    LOG_LEVEL = _env("SAAS_LOG_LEVEL", "INFO")

    # saas_platform — lectura/escritura
    SAAS_DB_URL = (
        f"mysql+pymysql://{_env('SAAS_DB_USER', required=True)}:{_env('SAAS_DB_PASS', required=True)}"
        f"@{_env('SAAS_DB_HOST', '127.0.0.1')}:{_env('SAAS_DB_PORT', '3306')}"
        f"/{_env('SAAS_DB_NAME', 'saas_platform')}?charset=utf8mb4"
    )
    # asterisk — SOLO lectura (cdr, sip_provider_pricing). Nunca se escribe.
    ASTERISK_RO_DB_URL = (
        f"mysql+pymysql://{_env('ASTERISK_RO_DB_USER', required=True)}:{_env('ASTERISK_RO_DB_PASS', required=True)}"
        f"@{_env('SAAS_DB_HOST', '127.0.0.1')}:{_env('SAAS_DB_PORT', '3306')}"
        f"/{_env('ASTERISK_RO_DB_NAME', 'asterisk')}?charset=utf8mb4"
    )

    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = ENV == "production"
