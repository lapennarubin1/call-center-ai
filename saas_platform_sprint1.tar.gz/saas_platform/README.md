# saas_platform — Sprint 1 (fundacion del core multi-producto)

Se despliega aislado en /opt/saas_platform. No toca Asterisk, la base `asterisk`,
landmark-panel, Jarvis ni Nara. Ver docs: Documento 11, 12 v2, 13, 14, 15.

Orden de ejecucion (VPS, como root):
  1. tar xzf saas_platform_sprint1.tar.gz -C /opt/  &&  /opt/saas_platform/scripts/install_structure.sh
  2. editar /opt/saas_platform/backend/.env  (passwords, SECRET_KEY)
  3. /opt/saas_platform/scripts/init_database.sh        # base + usuarios (pide root MariaDB)
  4. /opt/saas_platform/scripts/migrate.sh              # 17 tablas + catalogos
  5. cd /opt/saas_platform/docker && docker compose up -d --build
  6. /opt/saas_platform/scripts/create_initial_tenant.sh
  7. curl http://127.0.0.1:8100/api/v1/health
