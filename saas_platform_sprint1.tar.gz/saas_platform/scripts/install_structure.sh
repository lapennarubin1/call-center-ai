#!/usr/bin/env bash
# install_structure.sh — SP-07 (BLOQUE 1). Crea /opt/saas_platform desde el tarball.
# Uso en el VPS, como root:
#   tar xzf /root/saas_platform_sprint1.tar.gz -C /opt/
#   /opt/saas_platform/scripts/install_structure.sh
set -euo pipefail
ROOT=/opt/saas_platform
[ -d "$ROOT" ] || { echo "ERROR: $ROOT no existe (¿descomprimiste el tar en /opt/?)"; exit 1; }
id -u saas >/dev/null 2>&1 || useradd -r -s /usr/sbin/nologin -d "$ROOT" saas
mkdir -p "$ROOT/logs/nginx"
chmod +x "$ROOT"/scripts/*.sh
[ -f "$ROOT/backend/.env" ] || { cp "$ROOT/backend/.env.example" "$ROOT/backend/.env"; echo ">> creado backend/.env desde el ejemplo: EDITARLO antes de continuar"; }
chmod 600 "$ROOT/backend/.env"
chown -R root:root "$ROOT"; chown -R saas:saas "$ROOT/logs"
echo "Estructura:"; find "$ROOT" -maxdepth 2 -type d | sort
