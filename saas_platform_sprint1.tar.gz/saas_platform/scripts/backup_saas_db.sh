#!/usr/bin/env bash
# backup_saas_db.sh — SP-12. Dump CONJUNTO de asterisk + saas_platform en la
# misma corrida y transaccion (hay referencias de tenant_id entre ambas).
# Solo LEE. Se ejecuta como root de MariaDB. Salida: /root/backups/
set -euo pipefail
OUT_DIR="${1:-/root/backups}"; mkdir -p "$OUT_DIR"; chmod 700 "$OUT_DIR"
TS="$(date +%Y%m%d_%H%M%S)"
FILE="$OUT_DIR/db_asterisk_saas_platform_${TS}.sql.gz"
echo "Se pedira el password de root de MariaDB."
mysqldump -u root -p --single-transaction --routines --triggers --events \
  --databases asterisk saas_platform | gzip > "$FILE"
chmod 600 "$FILE"
echo "OK -> $FILE ($(du -h "$FILE" | cut -f1))"
echo "Verificacion rapida (tablas incluidas):"; zcat "$FILE" | grep -c "^CREATE TABLE" || true
