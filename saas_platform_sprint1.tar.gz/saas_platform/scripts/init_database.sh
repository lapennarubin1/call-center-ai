#!/usr/bin/env bash
# init_database.sh — SP-08. Crea la base saas_platform y los usuarios saas_rw /
# saas_ro_asterisk leyendo los passwords de backend/.env. Se ejecuta UNA vez,
# como root de MariaDB. NO modifica ninguna tabla de asterisk (solo GRANT SELECT).
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
set -a; . "$ROOT/backend/.env"; set +a
: "${SAAS_DB_PASS:?}" "${ASTERISK_RO_DB_PASS:?}"
echo "Se pedira el password de root de MariaDB."
sed -e "s|__SAAS_RW_PASSWORD__|${SAAS_DB_PASS}|g" -e "s|__SAAS_RO_PASSWORD__|${ASTERISK_RO_DB_PASS}|g" \
  "$ROOT/database/000_create_database_and_users.sql" | mysql -u root -p
echo "OK. Verificacion de permisos:"
mysql -u root -p -e "SHOW GRANTS FOR 'saas_rw'@'localhost'; SHOW GRANTS FOR 'saas_ro_asterisk'@'localhost';"
