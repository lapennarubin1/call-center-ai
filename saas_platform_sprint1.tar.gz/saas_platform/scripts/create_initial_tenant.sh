#!/usr/bin/env bash
# create_initial_tenant.sh — crea el tenant inicial de validacion (id=1, alineado
# con asterisk.tenants id=1 de Fase 0) y su usuario owner, desde SAAS_INITIAL_* del .env.
# Corre DENTRO del contenedor backend (usa su Python y su .env).
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/../docker"
docker compose exec backend flask --app app create-tenant --tenant-id 1
