#!/usr/bin/env bash
# deploy.sh — despliegue de la plataforma SaaS. Independiente de landmark-panel.
# Uso: ./scripts/deploy.sh            (build + up + migraciones pendientes + health)
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT/docker"
echo ">> build + up"; docker compose up -d --build
echo ">> migraciones pendientes"; "$ROOT/scripts/migrate.sh"
echo ">> esperando backend"; for i in $(seq 1 20); do
  if curl -fsS http://127.0.0.1:8100/api/v1/health >/dev/null 2>&1; then break; fi; sleep 2; done
echo ">> health:"; curl -sS http://127.0.0.1:8100/api/v1/health; echo
docker compose ps
