#!/usr/bin/env bash
# migrate.sh — aplica las migraciones SQL de database/migrations/ en orden,
# una sola vez cada una, registrandolas en saas_platform.schema_migrations.
#
# Uso (en el VPS, desde /opt/saas_platform):
#   ./scripts/migrate.sh            # aplica pendientes
#   ./scripts/migrate.sh --status   # solo muestra aplicadas / pendientes
#
# Lee credenciales de backend/.env (SAAS_DB_*). Nunca toca la base asterisk.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="$ROOT/backend/.env"
MIG_DIR="$ROOT/database/migrations"

[ -f "$ENV_FILE" ] || { echo "ERROR: falta $ENV_FILE (copiar desde backend/.env.example)"; exit 1; }
# shellcheck disable=SC1090
set -a; . "$ENV_FILE"; set +a

DB_HOST="${SAAS_DB_HOST_LOCAL:-127.0.0.1}"   # desde el host se usa 127.0.0.1, no la gateway docker
DB_PORT="${SAAS_DB_PORT:-3306}"
DB_NAME="${SAAS_DB_NAME:?SAAS_DB_NAME no definido}"
DB_USER="${SAAS_DB_USER:?SAAS_DB_USER no definido}"
DB_PASS="${SAAS_DB_PASS:?SAAS_DB_PASS no definido}"

MYSQL=(mysql --host="$DB_HOST" --port="$DB_PORT" --user="$DB_USER" --password="$DB_PASS" --database="$DB_NAME" --batch --skip-column-names)

"${MYSQL[@]}" -e "CREATE TABLE IF NOT EXISTS schema_migrations (
  version VARCHAR(80) PRIMARY KEY,
  applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;"

applied="$("${MYSQL[@]}" -e "SELECT version FROM schema_migrations ORDER BY version;")"

if [ "${1:-}" = "--status" ]; then
  echo "== Aplicadas =="; echo "${applied:-(ninguna)}"
  echo "== Pendientes =="
  for f in "$MIG_DIR"/*.sql; do v="$(basename "$f" .sql)"; grep -qx "$v" <<<"$applied" || echo "$v"; done
  exit 0
fi

count=0
for f in "$MIG_DIR"/*.sql; do
  v="$(basename "$f" .sql)"
  if grep -qx "$v" <<<"$applied"; then continue; fi
  echo ">> aplicando $v"
  "${MYSQL[@]}" < "$f"
  "${MYSQL[@]}" -e "INSERT INTO schema_migrations (version) VALUES ('$v');"
  count=$((count+1))
done
echo "OK — $count migracion(es) aplicada(s)."
