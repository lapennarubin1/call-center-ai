-- 000_create_database_and_users.sql
-- Ejecutar UNA sola vez como root de MariaDB. Crea la base saas_platform y
-- los usuarios con permisos minimos. NO toca la base asterisk (solo concede
-- SELECT sobre 2 tablas a un usuario de solo lectura).
--
-- ANTES de ejecutar, reemplazar los 2 placeholders de password:
--   __SAAS_RW_PASSWORD__   __SAAS_RO_PASSWORD__
-- (scripts/init_database.sh lo hace automaticamente leyendo backend/.env)
--
-- Hosts permitidos:
--   localhost      -> para el CLI / scripts desde el host
--   172.30.0.%     -> subred de las redes Docker de saas_platform (docker/docker-compose.yml)

CREATE DATABASE IF NOT EXISTS saas_platform
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Usuario de lectura/escritura: SOLO saas_platform
CREATE USER IF NOT EXISTS 'saas_rw'@'localhost'  IDENTIFIED BY '__SAAS_RW_PASSWORD__';
CREATE USER IF NOT EXISTS 'saas_rw'@'172.30.0.%' IDENTIFIED BY '__SAAS_RW_PASSWORD__';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, DROP, REFERENCES, CREATE VIEW
  ON saas_platform.* TO 'saas_rw'@'localhost';
GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, ALTER, INDEX, DROP, REFERENCES, CREATE VIEW
  ON saas_platform.* TO 'saas_rw'@'172.30.0.%';

-- Usuario de SOLO LECTURA sobre lo minimo de asterisk que necesita el SaaS
-- (consumo de minutos y tarifas). Nunca escritura.
CREATE USER IF NOT EXISTS 'saas_ro_asterisk'@'localhost'  IDENTIFIED BY '__SAAS_RO_PASSWORD__';
CREATE USER IF NOT EXISTS 'saas_ro_asterisk'@'172.30.0.%' IDENTIFIED BY '__SAAS_RO_PASSWORD__';
GRANT SELECT ON asterisk.cdr                  TO 'saas_ro_asterisk'@'localhost';
GRANT SELECT ON asterisk.cdr                  TO 'saas_ro_asterisk'@'172.30.0.%';
GRANT SELECT ON asterisk.sip_provider_pricing TO 'saas_ro_asterisk'@'localhost';
GRANT SELECT ON asterisk.sip_provider_pricing TO 'saas_ro_asterisk'@'172.30.0.%';

FLUSH PRIVILEGES;
