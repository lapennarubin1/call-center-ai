-- 006_module_crm.sql
-- MODULE crm: crm_lead_sources, crm_leads

CREATE TABLE IF NOT EXISTS crm_lead_sources (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  tenant_integration_id INT NULL COMMENT 'NULL para internal / csv_upload',
  type ENUM('internal','csv_upload','google_sheets','hubspot','salesforce','zoho','pipedrive','gohighlevel','custom_api') NOT NULL,
  label VARCHAR(100) NULL,
  sync_mode ENUM('pull','push_webhook') NOT NULL DEFAULT 'push_webhook',
  sync_config JSON NULL COMMENT 'sheet_id+range, pipeline/stage mapping, etc.',
  webhook_token VARCHAR(64) NULL COMMENT 'token para validar webhooks entrantes (push)',
  status ENUM('active','disabled','error') NOT NULL DEFAULT 'active',
  last_sync_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_crm_lead_sources_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id),
  CONSTRAINT fk_crm_lead_sources_integration FOREIGN KEY (tenant_integration_id) REFERENCES tenant_integrations(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS crm_leads (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  contact_id INT NOT NULL,
  source_id INT NULL,
  campaign_id INT NULL COMMENT 'voice_campaigns.id si el lead esta asignado a una campana de voz',
  external_id VARCHAR(150) NULL COMMENT 'id del lead en el sistema de origen',
  status ENUM('new','ready_to_call','calling','contacted','no_answer','converted','opted_out','discarded') NOT NULL DEFAULT 'new',
  stage VARCHAR(60) NULL COMMENT 'etapa de pipeline (libre por tenant)',
  score INT NULL,
  notes TEXT NULL,
  last_contact_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_crm_leads_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id),
  CONSTRAINT fk_crm_leads_contact FOREIGN KEY (contact_id) REFERENCES contacts(id),
  CONSTRAINT fk_crm_leads_source FOREIGN KEY (source_id) REFERENCES crm_lead_sources(id),
  CONSTRAINT fk_crm_leads_campaign FOREIGN KEY (campaign_id) REFERENCES voice_campaigns(id),
  INDEX idx_crm_leads_tenant_status (tenant_id, status),
  INDEX idx_crm_leads_source_external (source_id, external_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
