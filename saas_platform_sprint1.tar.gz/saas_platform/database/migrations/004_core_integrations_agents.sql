-- 004_core_integrations_agents.sql
-- CORE: integration_providers (catalogo), tenant_integrations (instancias), agents

CREATE TABLE IF NOT EXISTS integration_providers (
  provider_key VARCHAR(40) PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  category ENUM('crm','messaging','email','calendar','payments','telephony','voice','custom') NOT NULL,
  auth_type ENUM('oauth2','api_key','webhook_token','none') NOT NULL DEFAULT 'api_key',
  capabilities JSON NULL COMMENT 'ej. ["contacts.pull","contacts.push","messages.send"]',
  status ENUM('available','beta','planned','deprecated') NOT NULL DEFAULT 'planned',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS tenant_integrations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  provider_key VARCHAR(40) NOT NULL,
  label VARCHAR(100) NULL,
  config_ref VARCHAR(160) NOT NULL COMMENT 'nombre del secreto (env/vault). NUNCA el valor',
  settings JSON NULL COMMENT 'configuracion NO sensible (ids de cuenta, pipeline, etc.)',
  status ENUM('active','disabled','error') NOT NULL DEFAULT 'active',
  last_sync_at DATETIME NULL,
  last_error TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_tenant_integrations_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id),
  CONSTRAINT fk_tenant_integrations_provider FOREIGN KEY (provider_key) REFERENCES integration_providers(provider_key),
  INDEX idx_tenant_integrations_tenant (tenant_id, provider_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS agents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  name VARCHAR(120) NOT NULL,
  type ENUM('voice','chat','whatsapp','email','workflow') NOT NULL DEFAULT 'voice',
  language VARCHAR(10) NOT NULL DEFAULT 'es',
  model_provider VARCHAR(40) NULL COMMENT 'anthropic, openai, ...',
  model_name VARCHAR(80) NULL,
  voice_provider VARCHAR(40) NULL COMMENT 'elevenlabs, ... (solo type=voice)',
  voice_id VARCHAR(100) NULL,
  system_prompt TEXT NULL,
  channel_config JSON NULL COMMENT 'config especifica del canal',
  status ENUM('active','disabled') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_agents_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id),
  INDEX idx_agents_tenant_type (tenant_id, type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
