-- 005_module_voice_ai.sql
-- MODULE voice_ai: voice_campaigns, voice_calls

CREATE TABLE IF NOT EXISTS voice_campaigns (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  agent_id INT NOT NULL,
  name VARCHAR(120) NOT NULL,
  country VARCHAR(2) NOT NULL COMMENT 'ISO-3166-1 alpha-2, ej. MX, IN, AE',
  timezone VARCHAR(50) NOT NULL,
  schedule_start TIME NULL,
  schedule_end TIME NULL,
  schedule_days VARCHAR(20) NULL COMMENT 'ej. mon-fri',
  daily_limit INT NULL,
  status ENUM('draft','active','paused','finished') NOT NULL DEFAULT 'draft',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_voice_campaigns_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id),
  CONSTRAINT fk_voice_campaigns_agent FOREIGN KEY (agent_id) REFERENCES agents(id),
  INDEX idx_voice_campaigns_tenant_status (tenant_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS voice_calls (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  campaign_id INT NULL,
  contact_id INT NULL,
  agent_id INT NULL,
  direction ENUM('outbound','inbound') NOT NULL DEFAULT 'outbound',
  cdr_uniqueid VARCHAR(150) NULL COMMENT 'referencia a asterisk.cdr.uniqueid. NUNCA FK real: cdr es de Asterisk',
  phone_e164 VARCHAR(20) NULL,
  started_at DATETIME NULL,
  duration_seconds INT NULL,
  billsec INT NULL COMMENT 'segundos facturables (igual que cdr.billsec)',
  status VARCHAR(30) NULL COMMENT 'ANSWERED, NO ANSWER, BUSY, FAILED...',
  outcome VARCHAR(40) NULL COMMENT 'resultado de negocio: interested, callback, not_interested...',
  recording_reference VARCHAR(255) NULL,
  transcript_reference VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_voice_calls_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id),
  CONSTRAINT fk_voice_calls_campaign FOREIGN KEY (campaign_id) REFERENCES voice_campaigns(id),
  CONSTRAINT fk_voice_calls_contact FOREIGN KEY (contact_id) REFERENCES contacts(id),
  CONSTRAINT fk_voice_calls_agent FOREIGN KEY (agent_id) REFERENCES agents(id),
  INDEX idx_voice_calls_cdr (cdr_uniqueid),
  INDEX idx_voice_calls_tenant_started (tenant_id, started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
