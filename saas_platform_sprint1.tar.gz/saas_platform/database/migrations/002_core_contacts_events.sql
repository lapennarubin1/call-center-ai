-- 002_core_contacts_events.sql
-- CORE: contacts (identidad unificada), domain_events (outbox)

CREATE TABLE IF NOT EXISTS contacts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  full_name VARCHAR(150) NULL,
  phone_e164 VARCHAR(20) NULL COMMENT 'telefono normalizado E.164, ej. +5215512345678',
  email VARCHAR(160) NULL,
  country VARCHAR(2) NULL COMMENT 'ISO-3166-1 alpha-2',
  timezone VARCHAR(50) NULL,
  opt_out_voice TINYINT(1) NOT NULL DEFAULT 0,
  opt_out_messaging TINYINT(1) NOT NULL DEFAULT 0,
  attributes JSON NULL COMMENT 'campos libres por tenant',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_contacts_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id),
  INDEX idx_contacts_tenant_phone (tenant_id, phone_e164),
  INDEX idx_contacts_tenant_email (tenant_id, email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- La deduplicacion (mismo telefono/email dentro de un tenant) se hace en
-- core/contacts, no con UNIQUE: un contacto puede no tener telefono ni email.

CREATE TABLE IF NOT EXISTS domain_events (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  module_key VARCHAR(40) NOT NULL COMMENT 'core, voice_ai, crm, ...',
  event_type VARCHAR(80) NOT NULL COMMENT 'ej. contact.created, voice.call.completed',
  aggregate_type VARCHAR(40) NULL,
  aggregate_id BIGINT NULL,
  payload JSON NULL,
  created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  processed_at DATETIME(3) NULL,
  CONSTRAINT fk_domain_events_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id),
  INDEX idx_domain_events_pending (processed_at, id),
  INDEX idx_domain_events_tenant_type (tenant_id, event_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
