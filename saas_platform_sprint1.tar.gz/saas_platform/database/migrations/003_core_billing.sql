-- 003_core_billing.sql
-- CORE/BILLING: billable_services, plan_entitlements, usage_events

CREATE TABLE IF NOT EXISTS billable_services (
  service_key VARCHAR(40) PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  unit VARCHAR(30) NOT NULL COMMENT 'minute, message, token, run, send, seat',
  module_key VARCHAR(40) NOT NULL COMMENT 'modulo que lo emite',
  status ENUM('active','deprecated') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS plan_entitlements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  plan_id INT NOT NULL,
  service_key VARCHAR(40) NOT NULL,
  included_quantity DECIMAL(14,4) NOT NULL DEFAULT 0,
  overage_price_usd DECIMAL(10,6) NOT NULL DEFAULT 0 COMMENT 'precio por unidad excedente',
  hard_limit TINYINT(1) NOT NULL DEFAULT 0 COMMENT '1 = bloquear al agotar en vez de cobrar excedente',
  CONSTRAINT fk_plan_entitlements_plan FOREIGN KEY (plan_id) REFERENCES plans(id),
  CONSTRAINT fk_plan_entitlements_service FOREIGN KEY (service_key) REFERENCES billable_services(service_key),
  CONSTRAINT uq_plan_entitlements UNIQUE (plan_id, service_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS usage_events (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  service_key VARCHAR(40) NOT NULL,
  quantity DECIMAL(14,4) NOT NULL,
  cost_usd DECIMAL(12,6) NOT NULL DEFAULT 0 COMMENT 'lo que pagamos al proveedor',
  price_usd DECIMAL(12,6) NOT NULL DEFAULT 0 COMMENT 'lo que cobramos al tenant',
  reference_id VARCHAR(150) NOT NULL COMMENT 'idempotencia: cdr uniqueid, message id, run id...',
  occurred_at DATETIME NOT NULL,
  metadata JSON NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_usage_events_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id),
  CONSTRAINT fk_usage_events_service FOREIGN KEY (service_key) REFERENCES billable_services(service_key),
  CONSTRAINT uq_usage_events_ref UNIQUE (tenant_id, service_key, reference_id),
  INDEX idx_usage_events_tenant_period (tenant_id, service_key, occurred_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
