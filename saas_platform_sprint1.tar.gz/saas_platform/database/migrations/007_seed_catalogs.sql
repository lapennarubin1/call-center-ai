-- 007_seed_catalogs.sql
-- Datos de catalogo (globales, sin tenant). El tenant inicial y su usuario
-- se crean con el CLI del backend (scripts/create_initial_tenant.sh), nunca
-- hardcodeados aqui: la plataforma es agnostica del cliente.

INSERT IGNORE INTO billable_services (service_key, name, unit, module_key) VALUES
  ('voice_minutes',    'Minutos de llamada de voz',      'minute',  'voice_ai'),
  ('ai_tokens_in',     'Tokens IA de entrada',           'token',   'core'),
  ('ai_tokens_out',    'Tokens IA de salida',            'token',   'core'),
  ('conversations',    'Conversaciones iniciadas',       'conversation', 'core'),
  ('automation_runs',  'Ejecuciones de automatizacion',  'run',     'automation'),
  ('wa_messages',      'Mensajes WhatsApp',              'message', 'whatsapp'),
  ('wa_conversations', 'Conversaciones WhatsApp (24h)',  'conversation', 'whatsapp'),
  ('email_sends',      'Emails enviados',                'send',    'email'),
  ('seats',            'Usuarios activos',               'seat',    'core');

INSERT IGNORE INTO integration_providers (provider_key, name, category, auth_type, capabilities, status) VALUES
  ('sip_trunk',        'Proveedor SIP (trunk)',      'telephony', 'none',          '["calls.outbound"]', 'available'),
  ('elevenlabs',       'ElevenLabs',                 'voice',     'api_key',       '["voice.tts","voice.agent"]', 'available'),
  ('telegram',         'Telegram Bot',               'messaging', 'api_key',       '["messages.send","messages.receive"]', 'available'),
  ('google_sheets',    'Google Sheets',              'crm',       'oauth2',        '["contacts.pull"]', 'available'),
  ('custom_api',       'API personalizada',          'custom',    'webhook_token', '["contacts.push","events.push"]', 'available'),
  ('hubspot',          'HubSpot',                    'crm',       'oauth2',        '["contacts.pull","contacts.push","deals.update"]', 'planned'),
  ('salesforce',       'Salesforce',                 'crm',       'oauth2',        '["contacts.pull","contacts.push"]', 'planned'),
  ('zoho',             'Zoho CRM',                   'crm',       'oauth2',        '["contacts.pull","contacts.push"]', 'planned'),
  ('pipedrive',        'Pipedrive',                  'crm',       'api_key',       '["contacts.pull","contacts.push","deals.update"]', 'planned'),
  ('gohighlevel',      'GoHighLevel',                'crm',       'api_key',       '["contacts.pull","contacts.push"]', 'planned'),
  ('meta_whatsapp',    'Meta WhatsApp Cloud API',    'messaging', 'api_key',       '["messages.send","messages.receive","templates.send"]', 'planned'),
  ('gmail',            'Gmail',                      'email',     'oauth2',        '["email.send","email.read"]', 'planned'),
  ('outlook',          'Microsoft Outlook',          'email',     'oauth2',        '["email.send","email.read"]', 'planned'),
  ('google_calendar',  'Google Calendar',            'calendar',  'oauth2',        '["calendar.read","calendar.write"]', 'planned'),
  ('outlook_calendar', 'Outlook Calendar',           'calendar',  'oauth2',        '["calendar.read","calendar.write"]', 'planned');

-- Plan tecnico para el tenant inicial de validacion: sin limites ni precio.
INSERT IGNORE INTO plans (slug, name, price_usd, billing_period) VALUES
  ('internal-unlimited', 'Internal Unlimited (validacion)', 0, 'monthly');

INSERT IGNORE INTO plan_entitlements (plan_id, service_key, included_quantity, overage_price_usd, hard_limit)
SELECT p.id, s.service_key, 999999999, 0, 0
FROM plans p CROSS JOIN billable_services s
WHERE p.slug = 'internal-unlimited';
