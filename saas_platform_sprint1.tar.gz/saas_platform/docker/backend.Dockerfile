FROM python:3.12-slim
ENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
# Usuario no-root dentro del contenedor (Documento 14, 3.4)
RUN groupadd -r saas && useradd -r -g saas -d /srv/app saas
WORKDIR /srv/app
COPY backend/requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY backend/ .
RUN chown -R saas:saas /srv/app
USER saas
EXPOSE 8000
HEALTHCHECK --interval=30s --timeout=5s --start-period=15s --retries=3 \
  CMD python -c "import urllib.request,sys; sys.exit(0 if urllib.request.urlopen('http://127.0.0.1:8000/api/v1/health').status==200 else 1)"
CMD ["gunicorn", "-c", "gunicorn.conf.py", "wsgi:app"]
