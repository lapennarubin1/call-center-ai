-- 009_agents_extend.sql
-- Extension ADITIVA de agents para soportar el bloque "Agents + ElevenLabs
-- config inicial". No modifica 001-008. No borra ni renombra ninguna
-- columna existente. Ninguna fila actual cambia de valor.
--
-- 1) description: texto libre opcional, no existia.
-- 2) locale: mercado/pais del agente (es-MX, en-IN, en-AE...), separado de
--    `language` (que ya existe y sigue guardando el idioma base "es"/"en").
--    No se reutiliza `language` para esto porque ya tiene un significado
--    distinto (idioma), y mezclar ambos conceptos en una sola columna
--    obligaria a parsear strings despues.
-- 3) status: se agrega 'draft' al ENUM. 'active' y 'disabled' se preservan
--    intactos; ninguna fila existente cambia. 'active' sigue sin poder
--    asignarse desde este bloque (bloqueado en el codigo del backend, no
--    solo en el ENUM).

ALTER TABLE agents
  ADD COLUMN description TEXT NULL AFTER name;

ALTER TABLE agents
  ADD COLUMN locale VARCHAR(10) NULL
  COMMENT 'mercado del agente: es-MX, en-IN, en-AE... catalogo en backend/app/modules/voice_ai/locales.py'
  AFTER language;

ALTER TABLE agents
  MODIFY COLUMN status ENUM('draft','active','disabled')
  NOT NULL DEFAULT 'draft';
