-- 010_agents_country_first_message.sql
-- Extension ADITIVA de agents. No modifica 001-009. No borra ni renombra
-- ninguna columna existente (language y locale se preservan intactos).
--
-- Justificacion (ver reporte de inspeccion del bloque):
-- country y first_message NO se guardan en channel_config (JSON) a
-- proposito: son campos centrales que se van a filtrar/consultar/editar
-- como cualquier otro campo de negocio, no configuracion incidental de un
-- canal externo. Guardarlos en JSON los sacaria del indice y complicaria
-- cualquier query futura de campanas/telephony routes que necesite
-- filtrar agentes por pais.
--
-- country: mercado del agente, ISO-3166-1 alpha-2, catalogo amplio en
--   backend/app/modules/voice_ai/markets.py. Independiente de `language`
--   y de `locale` — un agente en Kenya puede hablar ingles o swahili.
-- first_message: mensaje inicial que dice el agente al arrancar la
--   conversacion. Distinto de system_prompt (que ya tiene su columna).

ALTER TABLE agents
  ADD COLUMN country VARCHAR(2) NULL
  COMMENT 'mercado del agente (ISO-3166-1 alpha-2), independiente de language/locale'
  AFTER locale;

ALTER TABLE agents
  ADD COLUMN first_message TEXT NULL
  COMMENT 'mensaje inicial de la conversacion, distinto de system_prompt'
  AFTER system_prompt;
