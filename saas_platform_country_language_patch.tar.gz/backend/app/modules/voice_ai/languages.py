"""Catalogo de idiomas para Voice AI Agents (ISO-639-1).

Independiente de markets.py (pais/mercado). Un agente en Kenya puede
hablar ingles o swahili; un agente en UAE puede hablar ingles o arabe.
Ningun idioma queda atado a un pais especifico en este catalogo.

Ampliable sin tocar la logica que lo consume: agregar un idioma es agregar
una entrada a SUPPORTED_LANGUAGES.

Nota (preparacion para el futuro, sin implementar todavia — ver punto G):
no todos los proveedores de voz van a soportar todos estos idiomas. Ese
mapeo (provider capabilities -> supported languages) es trabajo de una
fase posterior; este modulo es solo el catalogo interno de idiomas que la
plataforma entiende, sin prometer que un proveedor en particular los tenga
disponibles todos.
"""

SUPPORTED_LANGUAGES: dict[str, str] = {
    "es": "Spanish",
    "en": "English",
    "hi": "Hindi",
    "ar": "Arabic",
    "ne": "Nepali",
    "sw": "Swahili",
    "pt": "Portuguese",
    "fr": "French",
    "de": "German",
    "it": "Italian",
    "zh": "Chinese",
    "ja": "Japanese",
    "ko": "Korean",
    "ru": "Russian",
    "tr": "Turkish",
    "ur": "Urdu",
    "bn": "Bengali",
    "id": "Indonesian",
    "vi": "Vietnamese",
    "th": "Thai",
}


def is_valid_language(code: str | None) -> bool:
    return bool(code) and code in SUPPORTED_LANGUAGES


def language_choices() -> list[tuple[str, str]]:
    """[(codigo, etiqueta), ...] ordenados alfabeticamente por etiqueta."""
    return sorted(SUPPORTED_LANGUAGES.items(), key=lambda kv: kv[1])


def language_label(code: str | None) -> str:
    return SUPPORTED_LANGUAGES.get(code or "", code or "—")
