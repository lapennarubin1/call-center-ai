"""Derivacion de `locale` (BCP-47-ish) a partir de language + country.

Ya NO es un catalogo fijo de combinaciones. Country y language se separaron
(ver migracion 010 y markets.py / languages.py) para no atar mercados
multilingues a una combinacion rigida — un agente en Kenya puede hablar
ingles o swahili sin que eso sea "kenia-ingles" vs "kenia-swahili"
predefinidos en una lista.

`agents.locale` sigue existiendo como columna (compatibilidad con datos ya
creados) — se calcula automaticamente aca, nunca lo elige el usuario
directamente, y jamas restringe que combinaciones de country+language son
validas: es un derivado informativo, no una regla de negocio.
"""


def build_locale(language: str | None, country: str | None) -> str | None:
    if not language:
        return None
    if not country:
        return language
    return f"{language}-{country.upper()}"
