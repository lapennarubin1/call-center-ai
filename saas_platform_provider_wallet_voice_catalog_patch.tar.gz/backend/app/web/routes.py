"""Blueprint 'web' — interfaz HTML (Jinja2) sobre el backend existente.

No reemplaza la API JSON (/api/v1/...): las paginas de esta capa hacen sus
propias lecturas de solo-lectura, con el MISMO criterio de tenant_id que ya
usan las rutas JSON de core/modules (siempre desde la sesion del servidor,
nunca desde el cliente). No se modifico ningun archivo de core/ ni de
modules/ para construir esta interfaz.
"""
from functools import wraps
import json
from flask import Blueprint, render_template, redirect, url_for, request, g
from sqlalchemy import text

from ..db import saas_session
from ..modules.voice_ai import countries as voice_countries
from ..modules.voice_ai import markets as voice_markets
from ..modules.voice_ai import languages as voice_languages
from ..modules.voice_ai import prompt_templates as voice_prompt_templates
from ..modules.voice_ai import elevenlabs as voice_elevenlabs
from ..modules.voice_ai import voice_engines as voice_engines

bp = Blueprint("web", __name__)
# Sin template_folder/static_folder propios: Flask(__name__) en app/__init__.py
# ya resuelve app/templates y app/static por defecto (mismo directorio).


# ---------------------------------------------------------------- helpers --

def login_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if not getattr(g, "tenant_id", None) or not getattr(g, "user_id", None):
            return redirect(url_for("web.login", next=request.path))
        return view(*args, **kwargs)
    return wrapper


def module_required(module_key: str):
    def deco(view):
        @wraps(view)
        def wrapper(*args, **kwargs):
            with saas_session() as s:
                enabled = _enabled_modules(s, g.tenant_id)
            if module_key not in enabled:
                return render_template(
                    "errors/403.html",
                    message=f"El modulo '{module_key}' no esta habilitado para este workspace.",
                ), 403
            return view(*args, **kwargs)
        return wrapper
    return deco


def _enabled_modules(session, tenant_id: int) -> list[str]:
    rows = session.execute(text(
        "SELECT module_key FROM tenant_modules WHERE tenant_id=:t AND status='enabled' ORDER BY module_key"
    ), {"t": tenant_id})
    return [r[0] for r in rows]


def _current_tenant(session, tenant_id: int) -> dict:
    row = session.execute(text(
        "SELECT id, slug, name, status FROM tenants WHERE id=:t"
    ), {"t": tenant_id}).mappings().first()
    return dict(row) if row else {}


def _current_user(session, user_id: int, role: str) -> dict:
    row = session.execute(text(
        "SELECT id, username, email FROM users WHERE id=:u"
    ), {"u": user_id}).mappings().first()
    data = dict(row) if row else {"username": "?"}
    data["role"] = role
    return data


def _page_shell():
    """Datos comunes a toda pagina autenticada: tenant, usuario, modulos."""
    with saas_session() as s:
        tenant = _current_tenant(s, g.tenant_id)
        user = _current_user(s, g.user_id, g.role)
        modules = _enabled_modules(s, g.tenant_id)
    return tenant, user, modules


# ------------------------------------------------------------------ rutas --

@bp.get("/")
def root():
    if getattr(g, "tenant_id", None):
        return redirect(url_for("web.dashboard"))
    return redirect(url_for("web.login"))


@bp.get("/login")
def login():
    if getattr(g, "tenant_id", None):
        return redirect(url_for("web.dashboard"))
    return render_template("login.html")


@bp.get("/dashboard")
@login_required
def dashboard():
    tenant, user, modules = _page_shell()
    with saas_session() as s:
        stats = {
            "modules_enabled": len(modules),
            "voice_campaigns": s.execute(text(
                "SELECT COUNT(*) FROM voice_campaigns WHERE tenant_id=:t"), {"t": g.tenant_id}).scalar() or 0,
            "voice_calls": s.execute(text(
                "SELECT COUNT(*) FROM voice_calls WHERE tenant_id=:t"), {"t": g.tenant_id}).scalar() or 0,
            "crm_leads": s.execute(text(
                "SELECT COUNT(*) FROM crm_leads WHERE tenant_id=:t"), {"t": g.tenant_id}).scalar() or 0,
            "agents": s.execute(text(
                "SELECT COUNT(*) FROM agents WHERE tenant_id=:t"), {"t": g.tenant_id}).scalar() or 0,
        }
    return render_template(
        "dashboard.html", active_page="dashboard",
        current_tenant=tenant, current_user=user, enabled_modules=modules, stats=stats,
    )


@bp.get("/voice/campaigns")
@login_required
@module_required("voice_ai")
def voice_campaigns():
    tenant, user, modules = _page_shell()
    with saas_session() as s:
        rows = s.execute(text("""
            SELECT c.id, c.name, c.status, c.country, c.created_at,
                   a.id AS agent_id, a.name AS agent_name,
                   (SELECT COUNT(*) FROM crm_leads l WHERE l.campaign_id = c.id AND l.tenant_id = c.tenant_id) AS leads_count,
                   (SELECT COUNT(*) FROM voice_calls v WHERE v.campaign_id = c.id AND v.tenant_id = c.tenant_id) AS calls_count
            FROM voice_campaigns c
            LEFT JOIN agents a ON a.id = c.agent_id
            WHERE c.tenant_id = :t
            ORDER BY c.id DESC
        """), {"t": g.tenant_id}).mappings().all()
    return render_template(
        "voice_campaigns.html", active_page="voice_campaigns",
        current_tenant=tenant, current_user=user, enabled_modules=modules,
        campaigns=[dict(r) for r in rows],
    )


@bp.get("/voice/campaigns/new")
@login_required
@module_required("voice_ai")
def voice_campaign_new():
    tenant, user, modules = _page_shell()
    with saas_session() as s:
        # IMPORTANTE: incluye 'draft' ademas de 'active'. Los agentes nacen
        # en draft y este bloque no permite pasarlos a active todavia — si
        # se filtrara solo por 'active', el selector quedaria vacio siempre.
        agents = s.execute(text(
            "SELECT id, name FROM agents WHERE tenant_id=:t AND status IN ('draft','active') ORDER BY name"
        ), {"t": g.tenant_id}).mappings().all()
    return render_template(
        "voice_campaign_form.html", active_page="voice_campaigns",
        current_tenant=tenant, current_user=user, enabled_modules=modules,
        mode="create", campaign=None,
        agents=[dict(a) for a in agents],
        country_choices=voice_countries.country_choices(),
    )


@bp.get("/voice/campaigns/<int:campaign_id>/edit")
@login_required
@module_required("voice_ai")
def voice_campaign_edit(campaign_id):
    tenant, user, modules = _page_shell()
    with saas_session() as s:
        campaign = s.execute(text("""
            SELECT id, name, description, status, country, agent_id
            FROM voice_campaigns WHERE id=:id AND tenant_id=:t
        """), {"id": campaign_id, "t": g.tenant_id}).mappings().first()
        if not campaign:
            return render_template("errors/404.html"), 404
        agents = s.execute(text(
            "SELECT id, name FROM agents WHERE tenant_id=:t AND status IN ('draft','active') ORDER BY name"
        ), {"t": g.tenant_id}).mappings().all()
    return render_template(
        "voice_campaign_form.html", active_page="voice_campaigns",
        current_tenant=tenant, current_user=user, enabled_modules=modules,
        mode="edit", campaign=dict(campaign),
        agents=[dict(a) for a in agents],
        country_choices=voice_countries.country_choices(),
    )


@bp.get("/voice/agents")
@login_required
@module_required("voice_ai")
def voice_agents():
    tenant, user, modules = _page_shell()
    with saas_session() as s:
        rows = s.execute(text("""
            SELECT a.id, a.name, a.status, a.language, a.country, a.voice_provider,
                   a.updated_at, vc.voice_name,
                   (SELECT COUNT(*) FROM voice_campaigns c WHERE c.agent_id = a.id AND c.tenant_id = a.tenant_id) AS campaigns_count
            FROM agents a
            LEFT JOIN (SELECT id, name AS voice_name FROM voice_catalog) vc ON vc.id = a.voice_catalog_id
            WHERE a.tenant_id = :t AND a.type = 'voice'
            ORDER BY a.id DESC
        """), {"t": g.tenant_id}).mappings().all()
    agents = [dict(r) for r in rows]
    return render_template(
        "voice_agents.html", active_page="voice_agents",
        current_tenant=tenant, current_user=user, enabled_modules=modules,
        agents=agents,
        country_labels=dict(voice_markets.SUPPORTED_COUNTRIES),
        language_labels=dict(voice_languages.GLOBAL_LANGUAGES),
    )


@bp.get("/voice/agents/new")
@login_required
@module_required("voice_ai")
def voice_agent_new():
    tenant, user, modules = _page_shell()
    with saas_session() as s:
        el_row = s.execute(text(
            "SELECT settings FROM tenant_integrations WHERE tenant_id=:t AND provider_key='elevenlabs'"
        ), {"t": g.tenant_id}).mappings().first()
    el_mode = None
    if el_row and el_row["settings"]:
        el_mode = json.loads(el_row["settings"]).get("mode")
    return render_template(
        "voice_agent_form.html", active_page="voice_agents",
        current_tenant=tenant, current_user=user, enabled_modules=modules,
        mode="create", agent=None,
        country_choices=voice_markets.country_choices(),
        language_choices=voice_languages.language_choices(),
        template_choices=voice_prompt_templates.template_choices(),
        prompt_templates=voice_prompt_templates.PROMPT_TEMPLATES,
        elevenlabs_mode=el_mode,
        system_prompt_limit=voice_engines.get_system_prompt_limit(voice_engines.DEFAULT_ENGINE)["limit"],
        first_message_limit=voice_engines.get_first_message_limit(voice_engines.DEFAULT_ENGINE)["limit"],
    )


@bp.get("/voice/agents/<int:agent_id>/edit")
@login_required
@module_required("voice_ai")
def voice_agent_edit(agent_id):
    tenant, user, modules = _page_shell()
    with saas_session() as s:
        agent = s.execute(text("""
            SELECT a.id, a.name, a.description, a.status, a.language, a.country, a.voice_provider,
                   a.system_prompt, a.first_message, vc.platform_voice_id
            FROM agents a
            LEFT JOIN voice_catalog vc ON vc.id = a.voice_catalog_id
            WHERE a.id=:id AND a.tenant_id=:t AND a.type='voice'
        """), {"id": agent_id, "t": g.tenant_id}).mappings().first()
        if not agent:
            return render_template("errors/404.html"), 404
        el_row = s.execute(text(
            "SELECT settings FROM tenant_integrations WHERE tenant_id=:t AND provider_key='elevenlabs'"
        ), {"t": g.tenant_id}).mappings().first()
    el_mode = None
    if el_row and el_row["settings"]:
        el_mode = json.loads(el_row["settings"]).get("mode")
    agent_dict = dict(agent)
    return render_template(
        "voice_agent_form.html", active_page="voice_agents",
        current_tenant=tenant, current_user=user, enabled_modules=modules,
        mode="edit", agent=agent_dict,
        country_choices=voice_markets.country_choices(),
        language_choices=voice_languages.language_choices(),
        template_choices=voice_prompt_templates.template_choices(),
        prompt_templates=voice_prompt_templates.PROMPT_TEMPLATES,
        elevenlabs_mode=el_mode,
        system_prompt_limit=voice_engines.get_system_prompt_limit(agent_dict.get("voice_provider"))["limit"],
        first_message_limit=voice_engines.get_first_message_limit(agent_dict.get("voice_provider"))["limit"],
    )


@bp.get("/voice/settings/elevenlabs")
@login_required
@module_required("voice_ai")
def voice_elevenlabs_settings():
    tenant, user, modules = _page_shell()
    with saas_session() as s:
        row = s.execute(text("""
            SELECT settings, config_ref FROM tenant_integrations
            WHERE tenant_id=:t AND provider_key='elevenlabs'
        """), {"t": g.tenant_id}).mappings().first()
    mode = None
    config_ref = None
    if row:
        config_ref = row["config_ref"]
        if row["settings"]:
            mode = json.loads(row["settings"]).get("mode")
    configured = voice_elevenlabs.is_configured(mode, config_ref) if mode else False
    return render_template(
        "voice_elevenlabs_settings.html", active_page="voice_elevenlabs",
        current_tenant=tenant, current_user=user, enabled_modules=modules,
        current_mode=mode, config_ref=config_ref, configured=configured,
    )


@bp.get("/crm/leads")
@login_required
@module_required("crm")
def crm_leads():
    tenant, user, modules = _page_shell()
    with saas_session() as s:
        rows = s.execute(text("""
            SELECT l.id, l.status, l.created_at,
                   c.full_name, c.phone_e164, c.email,
                   ls.label AS source_label
            FROM crm_leads l
            JOIN contacts c ON c.id = l.contact_id
            LEFT JOIN crm_lead_sources ls ON ls.id = l.source_id
            WHERE l.tenant_id = :t
            ORDER BY l.id DESC
            LIMIT 200
        """), {"t": g.tenant_id}).mappings().all()
    return render_template(
        "crm_leads.html", active_page="crm_leads",
        current_tenant=tenant, current_user=user, enabled_modules=modules,
        leads=[dict(r) for r in rows],
    )


_PLACEHOLDER_TITLES = {
    "voice_calls": "Llamadas",
    "crm_contacts": "Contactos",
    "integrations": "Integraciones",
    "agents": "Agentes IA",
    "settings": "Configuración",
}


@bp.get("/soon/<section>")
@login_required
def placeholder(section):
    tenant, user, modules = _page_shell()
    title = _PLACEHOLDER_TITLES.get(section, "Próximamente")
    return render_template(
        "placeholder.html", active_page=section,
        current_tenant=tenant, current_user=user, enabled_modules=modules,
        section_title=title,
    )
