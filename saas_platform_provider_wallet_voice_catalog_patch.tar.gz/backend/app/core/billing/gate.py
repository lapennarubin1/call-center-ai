"""Gate de facturacion pre-uso (punto K del bloque). Reutilizable por
CUALQUIER modulo que vaya a iniciar un uso facturable — no es exclusivo de
voice_ai a proposito, por eso vive en core/billing y no en modules/voice_ai.

No conecta con ningun dialer ni proveedor real todavia — es la funcion que
un futuro flujo de llamadas real llamaria ANTES de disparar nada."""
from decimal import Decimal
from sqlalchemy import text
from . import wallet as wallet_service


class GateDenied(Exception):
    def __init__(self, reason: str):
        self.reason = reason
        super().__init__(reason)


def can_start_billable_usage(session, tenant_id: int, service_key: str, estimated_amount) -> dict:
    """Verifica, en orden, las condiciones minimas para permitir un uso
    facturable. Lanza GateDenied con el motivo especifico en el primer
    check que falle. Devuelve un dict informativo si todo esta OK.

    Chequeos de este bloque: tenant activo, suscripcion activa, modulo
    habilitado (segun billable_services.module_key), wallet activa y con
    saldo disponible suficiente, entitlement del plan para el servicio.
    Chequeos futuros explicitamente NO incluidos aca todavia (punto K):
    estado de la campaña, concurrencia simultanea, capacidad del
    proveedor — se agregan cuando exista el flujo real de llamadas."""

    tenant = session.execute(text(
        "SELECT id, status FROM tenants WHERE id=:t"
    ), {"t": tenant_id}).mappings().first()
    if not tenant or tenant["status"] != "active":
        raise GateDenied("tenant_inactive")

    sub = session.execute(text(
        "SELECT status FROM subscriptions WHERE tenant_id=:t ORDER BY id DESC LIMIT 1"
    ), {"t": tenant_id}).mappings().first()
    if not sub or sub["status"] != "active":
        raise GateDenied("subscription_inactive")

    service = session.execute(text(
        "SELECT service_key, module_key FROM billable_services WHERE service_key=:s"
    ), {"s": service_key}).mappings().first()
    if not service:
        raise GateDenied("unknown_service")

    module_enabled = session.execute(text(
        "SELECT 1 FROM tenant_modules WHERE tenant_id=:t AND module_key=:m AND status='enabled'"
    ), {"t": tenant_id, "m": service["module_key"]}).first()
    if not module_enabled:
        raise GateDenied("module_disabled")

    wallet_row = wallet_service.get_wallet(session, tenant_id)
    if not wallet_row:
        raise GateDenied("wallet_not_found")
    if wallet_row["status"] != "active":
        raise GateDenied("wallet_suspended")
    available = wallet_row["balance"] - wallet_row["reserved_balance"]
    if Decimal(str(estimated_amount)) > available:
        raise GateDenied("insufficient_balance")

    entitlement = session.execute(text("""
        SELECT pe.included_quantity, pe.overage_price_usd, pe.hard_limit
        FROM tenants t JOIN plan_entitlements pe ON pe.plan_id = t.plan_id AND pe.service_key = :s
        WHERE t.id = :t
    """), {"t": tenant_id, "s": service_key}).mappings().first()
    if entitlement and entitlement["hard_limit"]:
        # Con hard_limit, verificar consumo del periodo quedaria para el
        # flujo real (necesita agregacion de usage_events por periodo) —
        # explicitamente diferido, no se implementa en este bloque.
        pass

    return {"ok": True, "available_balance": available, "service": service_key, "module": service["module_key"]}
