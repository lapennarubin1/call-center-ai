"""Wallet por tenant + ledger auditable (punto I/J del bloque).

Principio: el saldo logico de la plataforma SIEMPRE manda, aunque el
proveedor externo permita seguir consumiendo. Un tenant nunca puede tocar
el saldo de otro (aislado por tenant_id, como el resto del sistema).

Concurrencia (punto J): "SELECT ... FOR UPDATE" sobre la fila de
tenant_wallets dentro de una transaccion InnoDB. Esa fila actua como lock
natural — dos requests concurrentes del MISMO tenant se serializan en esa
sentencia; el segundo espera a que el primero haga commit/rollback antes
de leer el balance, evitando la carrera "balance > 0 -> true" en ambos.

DECIMAL en toda la cadena — nunca float. amount siempre positivo; el
signo/efecto lo da entry_type, no el signo del numero.
"""
from decimal import Decimal, InvalidOperation
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError


class WalletError(Exception):
    """Error de dominio de wallet (fondos insuficientes, wallet suspendida, etc.)."""


def _to_decimal(amount) -> Decimal:
    try:
        d = Decimal(str(amount))
    except InvalidOperation as e:
        raise WalletError("amount invalido") from e
    if d <= 0:
        raise WalletError("amount debe ser positivo — el signo lo da entry_type, no el numero")
    return d


def ensure_wallet(session, tenant_id: int, currency: str = "USD"):
    """Crea la wallet del tenant si todavia no existe (idempotente)."""
    session.execute(text("""
        INSERT IGNORE INTO tenant_wallets (tenant_id, currency, balance, reserved_balance, status)
        VALUES (:t, :c, 0, 0, 'active')
    """), {"t": tenant_id, "c": currency})


def get_wallet(session, tenant_id: int):
    return session.execute(text("""
        SELECT tenant_id, currency, balance, reserved_balance, status, updated_at
        FROM tenant_wallets WHERE tenant_id=:t
    """), {"t": tenant_id}).mappings().first()


def _lock_wallet(session, tenant_id: int):
    """SELECT ... FOR UPDATE — bloquea la fila hasta el commit/rollback de
    esta transaccion. Cualquier otra transaccion que intente lockear la
    misma fila (mismo tenant) espera aca — esto es lo que hace segura la
    concurrencia de reservas simultaneas del mismo tenant."""
    row = session.execute(text("""
        SELECT tenant_id, currency, balance, reserved_balance, status
        FROM tenant_wallets WHERE tenant_id=:t FOR UPDATE
    """), {"t": tenant_id}).mappings().first()
    if not row:
        raise WalletError("wallet no existe para este tenant — llamar ensure_wallet primero")
    return row


def credit(session, tenant_id: int, amount, idempotency_key: str, reference_type=None, reference_id=None, metadata=None) -> bool:
    """Acredita saldo (recarga). Devuelve False si idempotency_key ya se
    proceso antes (no duplica), True si se aplico."""
    amount = _to_decimal(amount)
    wallet = _lock_wallet(session, tenant_id)
    if not _write_ledger(session, tenant_id, "credit", amount, wallet["currency"], idempotency_key, reference_type, reference_id, metadata):
        return False
    session.execute(text("UPDATE tenant_wallets SET balance = balance + :a WHERE tenant_id=:t"), {"a": amount, "t": tenant_id})
    return True


def reserve(session, tenant_id: int, amount, idempotency_key: str, reference_type=None, reference_id=None, metadata=None) -> bool:
    """Reserva atomicamente `amount` del saldo DISPONIBLE (balance -
    reserved_balance). Lanza WalletError si no alcanza. Idempotente por
    idempotency_key: un retry con la misma key no reserva dos veces."""
    amount = _to_decimal(amount)
    wallet = _lock_wallet(session, tenant_id)
    if wallet["status"] != "active":
        raise WalletError(f"wallet no activa (status={wallet['status']})")
    available = wallet["balance"] - wallet["reserved_balance"]
    if amount > available:
        raise WalletError(f"saldo insuficiente: disponible={available}, solicitado={amount}")
    if not _write_ledger(session, tenant_id, "reserve", amount, wallet["currency"], idempotency_key, reference_type, reference_id, metadata):
        return False
    session.execute(text("UPDATE tenant_wallets SET reserved_balance = reserved_balance + :a WHERE tenant_id=:t"), {"a": amount, "t": tenant_id})
    return True


def release(session, tenant_id: int, amount, idempotency_key: str, reference_type=None, reference_id=None, metadata=None) -> bool:
    """Libera una reserva no utilizada (ej. llamada fallida antes de
    conectar). No mueve balance, solo reserved_balance."""
    amount = _to_decimal(amount)
    wallet = _lock_wallet(session, tenant_id)
    if not _write_ledger(session, tenant_id, "release", amount, wallet["currency"], idempotency_key, reference_type, reference_id, metadata):
        return False
    session.execute(text("""
        UPDATE tenant_wallets SET reserved_balance = GREATEST(0, reserved_balance - :a) WHERE tenant_id=:t
    """), {"a": amount, "t": tenant_id})
    return True


def settle(session, tenant_id: int, reserved_amount, actual_amount, idempotency_key: str, reference_type=None, reference_id=None, metadata=None) -> bool:
    """Liquida una reserva: libera `reserved_amount` de reserved_balance y
    debita `actual_amount` (puede ser distinto — ej. la llamada duro menos
    de lo estimado) de balance. Un solo asiento de tipo 'settlement' con
    ambos montos en metadata, para no duplicar ledger vs usage_events."""
    reserved_amount = _to_decimal(reserved_amount)
    actual_amount = _to_decimal(actual_amount)
    wallet = _lock_wallet(session, tenant_id)
    meta = dict(metadata or {})
    meta["reserved_amount"] = str(reserved_amount)
    meta["actual_amount"] = str(actual_amount)
    if not _write_ledger(session, tenant_id, "settlement", actual_amount, wallet["currency"], idempotency_key, reference_type, reference_id, meta):
        return False
    session.execute(text("""
        UPDATE tenant_wallets
        SET reserved_balance = GREATEST(0, reserved_balance - :r),
            balance = balance - :a
        WHERE tenant_id=:t
    """), {"r": reserved_amount, "a": actual_amount, "t": tenant_id})
    return True


def _write_ledger(session, tenant_id, entry_type, amount, currency, idempotency_key, reference_type, reference_id, metadata) -> bool:
    import json
    try:
        with session.begin_nested():
            session.execute(text("""
                INSERT INTO wallet_ledger (tenant_id, entry_type, amount, currency, reference_type, reference_id, idempotency_key, metadata)
                VALUES (:t, :et, :a, :c, :rt, :rid, :idem, :meta)
            """), {"t": tenant_id, "et": entry_type, "a": amount, "c": currency, "rt": reference_type,
                   "rid": reference_id, "idem": idempotency_key, "meta": json.dumps(metadata or {})})
        return True
    except IntegrityError:
        return False  # idempotency_key ya usado — no se duplica el movimiento
