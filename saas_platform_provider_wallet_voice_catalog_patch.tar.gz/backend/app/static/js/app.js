/* AI Business Platform — JS ligero, sin dependencias. */

(function () {
  "use strict";

  // ---------- Login ----------
  var loginForm = document.getElementById("login-form");
  if (loginForm) {
    var alertBox = document.getElementById("login-alert");
    var submitBtn = document.getElementById("login-submit");

    loginForm.addEventListener("submit", function (ev) {
      ev.preventDefault();
      var tenant = document.getElementById("tenant").value.trim();
      var username = document.getElementById("username").value.trim();
      var password = document.getElementById("password").value;

      alertBox.classList.remove("show");
      submitBtn.disabled = true;
      submitBtn.textContent = "Ingresando...";

      fetch("/api/v1/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({ tenant: tenant, username: username, password: password }),
      })
        .then(function (res) {
          return res.json().then(function (data) { return { ok: res.ok, data: data }; });
        })
        .then(function (result) {
          if (!result.ok) {
            throw new Error(result.data && result.data.error ? result.data.error : "No se pudo iniciar sesion");
          }
          var params = new URLSearchParams(window.location.search);
          var next = params.get("next");
          window.location.href = next && next.startsWith("/") ? next : "/dashboard";
        })
        .catch(function (err) {
          alertBox.textContent = err.message;
          alertBox.classList.add("show");
          submitBtn.disabled = false;
          submitBtn.textContent = "Ingresar";
        });
    });
  }

  // ---------- Logout ----------
  document.querySelectorAll("[data-logout]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      fetch("/api/v1/auth/logout", { method: "POST", credentials: "same-origin" })
        .finally(function () { window.location.href = "/login"; });
    });
  });

  // ---------- Sidebar movil ----------
  var menuToggle = document.querySelector("[data-menu-toggle]");
  var overlay = document.querySelector("[data-sidebar-overlay]");
  function closeSidebar() { document.body.classList.remove("sidebar-open"); }
  if (menuToggle) {
    menuToggle.addEventListener("click", function () {
      document.body.classList.toggle("sidebar-open");
    });
  }
  if (overlay) overlay.addEventListener("click", closeSidebar);

  // Cerrar sidebar movil al navegar
  document.querySelectorAll(".sidebar a.nav-item").forEach(function (a) {
    a.addEventListener("click", closeSidebar);
  });

  // ---------- Formulario de campaña (crear / editar) ----------
  var campaignForm = document.getElementById("campaign-form");
  if (campaignForm) {
    var cAlert = document.getElementById("form-alert");
    var cSuccess = document.getElementById("form-success");
    var cSubmit = document.getElementById("form-submit");
    var mode = campaignForm.getAttribute("data-mode");
    var campaignId = campaignForm.getAttribute("data-campaign-id");

    campaignForm.addEventListener("submit", function (ev) {
      ev.preventDefault();
      cAlert.classList.remove("show");
      cSuccess.classList.remove("show");
      cSubmit.disabled = true;
      cSubmit.textContent = mode === "create" ? "Creando..." : "Guardando...";

      var payload = {
        name: document.getElementById("name").value.trim(),
        description: document.getElementById("description").value.trim(),
        country: document.getElementById("country").value,
        agent_id: parseInt(document.getElementById("agent_id").value, 10),
      };
      var url = "/api/v1/voice/campaigns";
      var method = "POST";
      if (mode === "edit") {
        payload.status = document.getElementById("status").value;
        url = "/api/v1/voice/campaigns/" + campaignId;
        method = "PATCH";
      }

      fetch(url, {
        method: method,
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify(payload),
      })
        .then(function (res) {
          return res.json().then(function (data) { return { ok: res.ok, data: data }; });
        })
        .then(function (result) {
          if (!result.ok) {
            throw new Error(result.data && result.data.error ? result.data.error : "No se pudo guardar la campaña");
          }
          cSuccess.textContent = mode === "create" ? "Campaña creada. Redirigiendo..." : "Cambios guardados. Redirigiendo...";
          cSuccess.classList.add("show");
          setTimeout(function () { window.location.href = "/voice/campaigns"; }, 700);
        })
        .catch(function (err) {
          cAlert.textContent = err.message;
          cAlert.classList.add("show");
          cSubmit.disabled = false;
          cSubmit.textContent = mode === "create" ? "Crear campaña" : "Guardar cambios";
        });
    });
  }

  // ---------- Formulario de agente (crear / editar) ----------

  // Selector de voces (punto G): fetch al catalogo publico, filtrado por
  // el idioma elegido. Nunca envia ni recibe provider_voice_id — solo
  // platform_voice_id, guardado en el input oculto homonimo.
  var voiceCardsContainer = document.getElementById("voice-selector-cards");
  var voiceLoading = document.getElementById("voice-selector-loading");
  var voiceEmpty = document.getElementById("voice-selector-empty");
  var platformVoiceIdInput = document.getElementById("platform_voice_id");
  var languageSelectForVoices = document.getElementById("language");

  function renderVoiceCards(voices) {
    voiceCardsContainer.innerHTML = "";
    var selected = platformVoiceIdInput.value || window.__CURRENT_VOICE_ID__ || "";
    voices.forEach(function (v) {
      var card = document.createElement("div");
      card.className = "voice-card" + (v.platform_voice_id === selected ? " selected" : "");
      card.setAttribute("data-voice-id", v.platform_voice_id);
      var tierBadge = v.pricing_tier === "premium"
        ? '<span class="badge badge-paused"><span class="badge-dot"></span>Premium</span>'
        : '<span class="badge badge-draft"><span class="badge-dot"></span>Standard</span>';
      var surcharge = (parseFloat(v.customer_price_multiplier) > 1)
        ? '<div style="font-size:11px;color:var(--warning);margin-top:2px">+' + Math.round((parseFloat(v.customer_price_multiplier) - 1) * 100) + '% Voice AI usage</div>'
        : "";
      var previewBtn = v.preview_url
        ? '<button type="button" class="icon-btn voice-preview-btn" data-preview="' + v.preview_url + '" title="Preview">' + "\u25B6" + "</button>"
        : "";
      card.innerHTML =
        '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px">' +
        '<div><strong>' + v.name + '</strong><div style="font-size:12px;color:var(--text-muted)">' +
        (v.accent || v.language) + (v.gender ? ' · ' + v.gender : '') + '</div></div>' +
        previewBtn + '</div>' +
        '<div style="font-size:12px;color:var(--text-muted);margin-top:6px">' + (v.category || '') + '</div>' +
        tierBadge + surcharge;
      card.addEventListener("click", function (ev) {
        if (ev.target.closest(".voice-preview-btn")) return;
        platformVoiceIdInput.value = v.platform_voice_id;
        voiceCardsContainer.querySelectorAll(".voice-card").forEach(function (c) { c.classList.remove("selected"); });
        card.classList.add("selected");
      });
      voiceCardsContainer.appendChild(card);
    });

    voiceCardsContainer.querySelectorAll(".voice-preview-btn").forEach(function (btn) {
      btn.addEventListener("click", function (ev) {
        ev.stopPropagation();
        var url = btn.getAttribute("data-preview");
        var audio = new Audio(url);
        audio.play().catch(function () {});
      });
    });
  }

  function loadVoices() {
    if (!voiceCardsContainer) return;
    var lang = languageSelectForVoices ? languageSelectForVoices.value : "";
    voiceLoading.style.display = "block";
    voiceEmpty.style.display = "none";
    voiceCardsContainer.style.display = "none";
    var url = "/api/v1/voice/voices" + (lang ? "?language=" + encodeURIComponent(lang) : "");
    fetch(url, { credentials: "same-origin" })
      .then(function (res) { return res.json(); })
      .then(function (data) {
        voiceLoading.style.display = "none";
        var items = (data && data.items) || [];
        if (items.length === 0) {
          voiceEmpty.style.display = "block";
        } else {
          voiceCardsContainer.style.display = "grid";
          renderVoiceCards(items);
        }
      })
      .catch(function () {
        voiceLoading.textContent = "No se pudo cargar el catálogo de voces.";
      });
  }
  if (voiceCardsContainer) {
    loadVoices();
    if (languageSelectForVoices) languageSelectForVoices.addEventListener("change", loadVoices);
  }

  // Contadores dinamicos de System Prompt / First Message. El limite
  // efectivo viene del backend (voice_engines.get_*_limit), inyectado por
  // el template — nunca un numero fijo en este archivo. Nunca se trunca
  // el texto aca: el contador solo informa, el backend es quien rechaza.
  function wireCounter(textareaId, counterId, limit) {
    var textarea = document.getElementById(textareaId);
    var counter = document.getElementById(counterId);
    if (!textarea || !counter || !limit) return;
    var update = function () {
      var len = textarea.value.length;
      counter.textContent = len.toLocaleString() + " / " + limit.toLocaleString() + " characters";
      counter.style.color = len > limit ? "var(--danger)" : "var(--text-muted)";
    };
    textarea.addEventListener("input", update);
    update();
  }
  wireCounter("system_prompt", "system_prompt_counter", window.__SYSTEM_PROMPT_LIMIT__);
  wireCounter("first_message", "first_message_counter", window.__FIRST_MESSAGE_LIMIT__);

  var templateSelect = document.getElementById("template");
  var promptTextarea = document.getElementById("system_prompt");
  if (templateSelect && promptTextarea && window.__PROMPT_TEMPLATES__) {
    templateSelect.addEventListener("change", function () {
      var tpl = window.__PROMPT_TEMPLATES__[templateSelect.value];
      if (tpl && (!promptTextarea.value || confirm("Esto va a reemplazar el texto actual del prompt. ¿Continuar?"))) {
        promptTextarea.value = tpl.prompt;
      }
      templateSelect.value = "";
    });
  }

  var agentForm = document.getElementById("agent-form");
  if (agentForm) {
    var aAlert = document.getElementById("form-alert");
    var aSuccess = document.getElementById("form-success");
    var aSubmit = document.getElementById("form-submit");
    var aMode = agentForm.getAttribute("data-mode");
    var agentId = agentForm.getAttribute("data-agent-id");

    agentForm.addEventListener("submit", function (ev) {
      ev.preventDefault();
      aAlert.classList.remove("show");
      aSuccess.classList.remove("show");
      aSubmit.disabled = true;
      aSubmit.textContent = aMode === "create" ? "Creando..." : "Guardando...";

      var payload = {
        name: document.getElementById("name").value.trim(),
        description: document.getElementById("description").value.trim(),
        country: document.getElementById("country").value,
        language: document.getElementById("language").value,
        first_message: document.getElementById("first_message").value,
        voice_provider: document.getElementById("voice_provider").value,
        system_prompt: document.getElementById("system_prompt").value,
      };
      var platformVoiceIdEl = document.getElementById("platform_voice_id");
      if (platformVoiceIdEl && platformVoiceIdEl.value) {
        payload.platform_voice_id = platformVoiceIdEl.value;
      }
      var url = "/api/v1/voice/agents";
      var method = "POST";
      if (aMode === "edit") {
        payload.status = document.getElementById("status").value;
        url = "/api/v1/voice/agents/" + agentId;
        method = "PATCH";
      }

      fetch(url, {
        method: method,
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify(payload),
      })
        .then(function (res) {
          return res.json().then(function (data) { return { ok: res.ok, data: data }; });
        })
        .then(function (result) {
          if (!result.ok) {
            throw new Error(result.data && result.data.error ? result.data.error : "No se pudo guardar el agente");
          }
          aSuccess.textContent = aMode === "create" ? "Agente creado. Redirigiendo..." : "Cambios guardados. Redirigiendo...";
          aSuccess.classList.add("show");
          setTimeout(function () { window.location.href = "/voice/agents"; }, 700);
        })
        .catch(function (err) {
          aAlert.textContent = err.message;
          aAlert.classList.add("show");
          aSubmit.disabled = false;
          aSubmit.textContent = aMode === "create" ? "Crear agente" : "Guardar cambios";
        });
    });
  }

  // ---------- Configuración de ElevenLabs ----------
  var elevenlabsForm = document.getElementById("elevenlabs-form");
  if (elevenlabsForm) {
    var eAlert = document.getElementById("form-alert");
    var eSuccess = document.getElementById("form-success");
    var eSubmit = document.getElementById("form-submit");
    var byokNote = document.getElementById("byok-note");
    var modeRadios = elevenlabsForm.querySelectorAll('input[name="mode"]');

    var toggleByokNote = function () {
      var checked = elevenlabsForm.querySelector('input[name="mode"]:checked');
      byokNote.style.display = checked && checked.value === "byok" ? "block" : "none";
    };
    modeRadios.forEach(function (r) { r.addEventListener("change", toggleByokNote); });
    toggleByokNote();

    elevenlabsForm.addEventListener("submit", function (ev) {
      ev.preventDefault();
      eAlert.classList.remove("show");
      eSuccess.classList.remove("show");
      eSubmit.disabled = true;
      eSubmit.textContent = "Guardando...";

      var checked = elevenlabsForm.querySelector('input[name="mode"]:checked');
      fetch("/api/v1/voice/integrations/elevenlabs", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({ mode: checked ? checked.value : "" }),
      })
        .then(function (res) {
          return res.json().then(function (data) { return { ok: res.ok, data: data }; });
        })
        .then(function (result) {
          if (!result.ok) {
            throw new Error(result.data && result.data.error ? result.data.error : "No se pudo guardar la configuración");
          }
          eSuccess.textContent = "Modo guardado.";
          eSuccess.classList.add("show");
          eSubmit.disabled = false;
          eSubmit.textContent = "Guardar modo";
        })
        .catch(function (err) {
          eAlert.textContent = err.message;
          eAlert.classList.add("show");
          eSubmit.disabled = false;
          eSubmit.textContent = "Guardar modo";
        });
    });
  }
})();
