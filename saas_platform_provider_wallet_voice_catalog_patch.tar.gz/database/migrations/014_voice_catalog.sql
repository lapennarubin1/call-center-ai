-- 014_voice_catalog.sql
-- Nueva tabla. No modifica 001-013.
--
-- Justificacion de tener cache/catalogo LOCAL (ver reporte de bloque,
-- seccion D): sin esta tabla, el cliente tendria que elegir una voz
-- pasandole al backend un provider_voice_id crudo — exactamente lo que el
-- bloque prohibe exponer. Con la tabla:
--   - el cliente elige por platform_voice_id (nunca ve provider_voice_id)
--   - la disponibilidad se controla desde nuestro lado (available=0 sin
--     depender de que el proveedor responda en el momento)
--   - el pricing (provider_cost_multiplier / customer_price_multiplier)
--     es NUESTRO, no lo que diga el proveedor en vivo
--   - una voz de un proveedor puede quedar disponible para varias cuentas
--     (provider_account_id NULL = entrada de catalogo compartida, no
--     atada a una cuenta especifica) o exclusiva de una cuenta (BYOK)
--
-- provider_voice_id, provider_key y provider_account_id son INTERNOS: el
-- serializer de la API de agentes/voces NUNCA debe incluirlos en la
-- respuesta al tenant (se filtran en la capa de aplicacion, no aca).

CREATE TABLE IF NOT EXISTS voice_catalog (
  id INT AUTO_INCREMENT PRIMARY KEY,
  platform_voice_id VARCHAR(40) NOT NULL COMMENT 'ID publico, propio de la plataforma — lo unico que ve el cliente',
  provider_key VARCHAR(40) NOT NULL COMMENT 'INTERNO — nunca se expone al tenant',
  provider_account_id INT NULL COMMENT 'INTERNO — NULL = entrada de catalogo compartida entre cuentas managed',
  provider_voice_id VARCHAR(160) NOT NULL COMMENT 'INTERNO — id real de la voz en el proveedor, nunca se expone al tenant',
  name VARCHAR(120) NOT NULL,
  language VARCHAR(10) NOT NULL,
  locale VARCHAR(10) NULL,
  accent VARCHAR(60) NULL,
  gender VARCHAR(20) NULL,
  age VARCHAR(20) NULL,
  category VARCHAR(60) NULL,
  use_case VARCHAR(120) NULL,
  description TEXT NULL,
  preview_url VARCHAR(500) NULL,
  available TINYINT(1) NOT NULL DEFAULT 1,
  provider_cost_multiplier DECIMAL(6,3) NOT NULL DEFAULT 1.000 COMMENT 'INTERNO — nunca se expone al tenant',
  customer_price_multiplier DECIMAL(6,3) NOT NULL DEFAULT 1.000 COMMENT 'multiplicador que SI puede reflejarse en el precio mostrado al tenant',
  pricing_tier ENUM('standard','premium','custom') NOT NULL DEFAULT 'standard',
  disable_at DATETIME NULL COMMENT 'si el proveedor avisa notice period de baja de la voz',
  metadata JSON NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT uq_voice_catalog_platform_voice_id UNIQUE (platform_voice_id),
  CONSTRAINT fk_voice_catalog_provider FOREIGN KEY (provider_key) REFERENCES integration_providers(provider_key),
  CONSTRAINT fk_voice_catalog_provider_account FOREIGN KEY (provider_account_id) REFERENCES ai_provider_accounts(id),
  INDEX idx_voice_catalog_language (language, available),
  INDEX idx_voice_catalog_provider (provider_key, provider_voice_id),
  CHECK (json_valid(metadata))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Ahora si se puede agregar la FK de agents.voice_catalog_id (creada en
-- la migracion 013) hacia esta tabla.
ALTER TABLE agents
  ADD CONSTRAINT fk_agents_voice_catalog FOREIGN KEY (voice_catalog_id) REFERENCES voice_catalog(id);
