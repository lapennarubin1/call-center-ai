-- 015_tenant_wallets_ledger.sql
-- Nuevas tablas. No modifica 001-014.
--
-- DECIMAL, nunca FLOAT, para dinero (punto I del bloque). balance y
-- reserved_balance separados: available_balance = balance - reserved_balance
-- se calcula en la capa de aplicacion (no se materializa como columna, para
-- que nunca quede desincronizada de balance/reserved_balance).
--
-- Concurrencia (punto J): el aislamiento entre tenants ya lo da tenant_id
-- (nunca se cruza). La seguridad ante REQUESTS CONCURRENTES DEL MISMO
-- tenant se resuelve en la capa de aplicacion con
-- "SELECT ... FOR UPDATE" sobre la fila de tenant_wallets dentro de una
-- transaccion InnoDB antes de leer/mover balance — la fila actua como
-- lock natural. No se modela en el DDL porque es un patron de uso, no de
-- esquema; se implementa en core/billing/wallet.py.
--
-- wallet_ledger es el unico lugar donde se escribe historial financiero.
-- idempotency_key evita procesar el mismo movimiento dos veces (ej. un
-- retry de red) — UNIQUE por tenant.

CREATE TABLE IF NOT EXISTS tenant_wallets (
  tenant_id INT PRIMARY KEY,
  currency VARCHAR(3) NOT NULL DEFAULT 'USD',
  balance DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  reserved_balance DECIMAL(14,4) NOT NULL DEFAULT 0.0000,
  status ENUM('active','suspended') NOT NULL DEFAULT 'active',
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_tenant_wallets_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id),
  CONSTRAINT chk_tenant_wallets_non_negative CHECK (balance >= 0 AND reserved_balance >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wallet_ledger (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  tenant_id INT NOT NULL,
  entry_type ENUM('credit','debit','reserve','release','settlement','refund','adjustment') NOT NULL,
  amount DECIMAL(14,4) NOT NULL,
  currency VARCHAR(3) NOT NULL DEFAULT 'USD',
  reference_type VARCHAR(40) NULL COMMENT 'ej. usage_event, manual_topup, ...',
  reference_id VARCHAR(150) NULL,
  idempotency_key VARCHAR(150) NOT NULL,
  metadata JSON NULL,
  created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  CONSTRAINT fk_wallet_ledger_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id),
  CONSTRAINT uq_wallet_ledger_idempotency UNIQUE (tenant_id, idempotency_key),
  INDEX idx_wallet_ledger_tenant_created (tenant_id, created_at),
  INDEX idx_wallet_ledger_reference (reference_type, reference_id),
  CHECK (json_valid(metadata))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
