-- 012_ai_provider_accounts.sql
-- Nueva tabla. No modifica 001-011.
--
-- Representa CUENTAS reales de proveedores de IA (API credentials), no
-- una clave por agente. Una cuenta managed es compartida entre tenants
-- (tenant_id NULL); una cuenta BYOK pertenece a un tenant especifico.
--
-- secret_ref sigue el mismo patron ya usado en tenant_integrations
-- (Documento 11, seccion 5.3): nombre de variable de entorno o referencia
-- a vault, NUNCA el valor del secreto. Sin cifrado casero.
--
-- El CHECK garantiza a nivel de base de datos que una cuenta managed
-- nunca tenga tenant_id, y una BYOK siempre lo tenga — no depende de que
-- el codigo de aplicacion lo recuerde.

CREATE TABLE IF NOT EXISTS ai_provider_accounts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  provider_key VARCHAR(40) NOT NULL,
  account_type ENUM('managed','byok') NOT NULL,
  tenant_id INT NULL COMMENT 'NULL si managed/compartida; obligatorio si byok',
  secret_ref VARCHAR(160) NOT NULL COMMENT 'nombre de variable de entorno o vault ref — NUNCA el valor',
  display_name VARCHAR(120) NULL COMMENT 'uso interno/admin — nunca se expone a la API de tenant',
  status ENUM('active','disabled','error') NOT NULL DEFAULT 'active',
  subscription_plan VARCHAR(80) NULL COMMENT 'plan/tier del proveedor si aplica, ej. "scale"',
  external_account_ref VARCHAR(160) NULL COMMENT 'id de cuenta en el proveedor, si aplica',
  settings JSON NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_ai_provider_accounts_provider FOREIGN KEY (provider_key) REFERENCES integration_providers(provider_key),
  CONSTRAINT fk_ai_provider_accounts_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(id),
  CONSTRAINT chk_ai_provider_accounts_scope CHECK (
    (account_type = 'managed' AND tenant_id IS NULL) OR
    (account_type = 'byok' AND tenant_id IS NOT NULL)
  ),
  INDEX idx_ai_provider_accounts_provider (provider_key, account_type),
  INDEX idx_ai_provider_accounts_tenant (tenant_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
