-- 016_seed_provider_accounts.sql
-- Datos de catalogo (global, sin tenant). No modifica 001-015.
--
-- Relacion con tenant_integrations (ya existente desde bloques
-- anteriores): tenant_integrations.elevenlabs registra que MODO eligio
-- cada tenant (managed/byok) — eso no cambia. ai_provider_accounts (esta
-- migracion) registra la cuenta/credencial REAL que respalda esa
-- eleccion: para 'managed', TODOS los tenants que eligieron managed
-- comparten esta unica fila (tenant_id NULL); para 'byok', cada tenant
-- tendria su propia fila con tenant_id=<ese tenant>, creada cuando ese
-- tenant complete su configuracion (no se seedea aca, no existe todavia
-- ningun tenant BYOK real).
--
-- secret_ref sigue la misma convencion ya usada por
-- elevenlabs.config_ref_for() para modo managed — ahora tiene una fila
-- real en vez de ser solo una constante en codigo.
--
-- NO se seedea voice_catalog en esta migracion: publicar voces "de
-- ejemplo" como si fueran reales, sin haber sincronizado contra la API de
-- ElevenLabs (prohibido en este bloque), seria inventar informacion. El
-- catalogo de voces queda vacio hasta el bloque de sincronizacion real.

INSERT IGNORE INTO ai_provider_accounts
  (provider_key, account_type, tenant_id, secret_ref, display_name, status)
VALUES
  ('elevenlabs', 'managed', NULL, 'PLATFORM_ELEVENLABS_KEY', 'ElevenLabs — cuenta managed de la plataforma', 'active');
