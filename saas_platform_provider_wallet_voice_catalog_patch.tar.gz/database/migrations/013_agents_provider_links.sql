-- 013_agents_provider_links.sql
-- Extension ADITIVA de agents. No modifica 001-011 ni borra datos.
--
-- Diseño (ver reporte de bloque, seccion B): se agregan columnas
-- directamente a agents en vez de una tabla de union nueva, porque solo
-- existen 2 capacidades hoy (conversation, voice) y una tabla-columnas
-- es mas simple de consultar que una junction table para un caso de 1:2
-- capacidades fijas. Si en el futuro aparecen mas capacidades
-- (ej. "transcription_provider"), ahi si se justifica normalizar a una
-- tabla agent_provider_links — no antes.
--
-- conversation_provider: espejo de voice_provider pero para el motor de
--   conversacion (hoy siempre 'elevenlabs' tambien, pero conceptualmente
--   independiente — un agente podria usar OpenAI para conversar y
--   ElevenLabs solo para la voz).
-- *_provider_account_id: que CUENTA/API especifica de ese proveedor usa
--   este agente (ver ai_provider_accounts, migracion 012).
-- voice_catalog_id: referencia a la voz elegida por el cliente desde el
--   catalogo normalizado (ver voice_catalog, migracion 014) — reemplaza
--   el uso directo de la columna voice_id como campo editable por el
--   cliente. voice_id se preserva sin cambios: pasa a ser un campo
--   RESUELTO por el backend (cache del provider_voice_id real), nunca
--   aceptado directo del cliente desde este bloque en adelante.

ALTER TABLE agents
  ADD COLUMN conversation_provider VARCHAR(40) NULL COMMENT 'motor de conversacion, ej. elevenlabs — independiente de voice_provider' AFTER model_name,
  ADD COLUMN conversation_provider_account_id INT NULL AFTER conversation_provider,
  ADD COLUMN voice_provider_account_id INT NULL AFTER voice_provider,
  ADD COLUMN voice_catalog_id INT NULL COMMENT 'voz elegida por el cliente desde voice_catalog — reemplaza edicion directa de voice_id' AFTER voice_id;

ALTER TABLE agents
  ADD CONSTRAINT fk_agents_conversation_provider_account
    FOREIGN KEY (conversation_provider_account_id) REFERENCES ai_provider_accounts(id),
  ADD CONSTRAINT fk_agents_voice_provider_account
    FOREIGN KEY (voice_provider_account_id) REFERENCES ai_provider_accounts(id);

-- La FK a voice_catalog(id) se agrega en la migracion 014, despues de
-- crear esa tabla (no se puede referenciar una tabla que todavia no existe).
