-- 011_agents_system_prompt_mediumtext.sql
-- Extension ADITIVA de agents. No modifica 001-010. No borra datos, no
-- toca first_message (que ya soporta 64KB via TEXT, sin cambios en este
-- bloque). No modifica la semantica de la columna: sigue siendo texto
-- libre opcional (NULL permitido), solo cambia su capacidad maxima.
--
-- Por que MEDIUMTEXT y no LONGTEXT:
-- TEXT (actual) soporta ~64KB — alcanza para el prompt real de ~13KB de
-- referencia, pero deja el limite interno mas restrictivo de lo necesario
-- frente a providers que en el futuro acepten contextos mucho mayores.
-- MEDIUMTEXT soporta ~16MB: suficientemente amplio para cualquier prompt
-- razonable (ordenes de magnitud por encima de lo que un humano escribe a
-- mano) sin llegar a LONGTEXT (~4GB), que no tiene justificacion real para
-- este campo y solo agregaria overhead de almacenamiento sin beneficio
-- (MySQL/MariaDB reservan mas bytes de longitud de prefijo para LONGTEXT).
--
-- El limite EFECTIVO que ve el usuario nunca es el limite de la columna:
-- lo define voice_engines.get_system_prompt_limit() en la capa de
-- aplicacion (ver Documento de este bloque, seccion D). La columna solo
-- garantiza que el almacenamiento interno no sea la restriccion.

ALTER TABLE agents
  MODIFY COLUMN system_prompt MEDIUMTEXT NULL;
