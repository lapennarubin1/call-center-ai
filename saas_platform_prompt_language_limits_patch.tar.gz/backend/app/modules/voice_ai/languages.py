"""MODULE_ENABLED_LANGUAGES de Voice AI — subset del catalogo GLOBAL que
este modulo permite seleccionar hoy en el formulario de agentes.

Separacion de capas (ver core/catalogs/languages.py para la explicacion
completa de las tres capas):

  GLOBAL_LANGUAGES              universo ISO 639-1 completo (core/catalogs)
  MODULE_ENABLED_LANGUAGES       <- este archivo
  PROVIDER_SUPPORTED_LANGUAGES   futuro (voice_engines.py)

La UI de Voice AI consume PLATFORM_VOICE_ENABLED_LANGUAGES (alias de
MODULE_ENABLED_LANGUAGES para este modulo), nunca el catalogo global
directo — mostrar los 183 idiomas del mundo como si Voice AI los
soportara todos seria prometer algo que no esta confirmado.

Ampliable sin tocar la logica que lo consume: habilitar un idioma nuevo es
agregar su codigo a MODULE_ENABLED_LANGUAGES (debe existir en el catalogo
global) — se valida programaticamente que todo lo habilitado exista en el
universo global.
"""
from ...core.catalogs.languages import GLOBAL_LANGUAGES, language_label as _global_label

# Se mantienen los mismos idiomas ya habilitados previamente (es, en, hi,
# ar, ne, sw obligatorios + los que ya estaban disponibles) — ninguno se
# quita, para no romper compatibilidad con agentes ya creados.
MODULE_ENABLED_LANGUAGES: set[str] = {
    "es", "en", "hi", "ar", "ne", "sw",
    "pt", "fr", "de", "it", "zh", "ja", "ko", "ru", "tr", "ur", "bn", "id", "vi", "th",
}

# Alias explicito: es el subset que la UI de Voice AI debe consumir.
PLATFORM_VOICE_ENABLED_LANGUAGES = MODULE_ENABLED_LANGUAGES

# Invariante verificada al importar el modulo: todo lo habilitado debe
# existir en el catalogo global — si esto falla, es un error de datos, no
# algo que deba fallar en silencio en produccion.
_unknown = MODULE_ENABLED_LANGUAGES - set(GLOBAL_LANGUAGES)
if _unknown:
    raise RuntimeError(f"MODULE_ENABLED_LANGUAGES tiene codigos fuera del catalogo global: {_unknown}")


def is_valid_language(code: str | None) -> bool:
    return bool(code) and code in MODULE_ENABLED_LANGUAGES


def language_choices() -> list[tuple[str, str]]:
    """[(codigo, etiqueta), ...] ordenados alfabeticamente por etiqueta —
    solo el subset habilitado, usando el nombre del catalogo global."""
    return sorted(((c, _global_label(c)) for c in MODULE_ENABLED_LANGUAGES), key=lambda kv: kv[1])


def language_label(code: str | None) -> str:
    return _global_label(code)
