"""Catalogo interno de motores de voz IA — METADATA, no funcionalidad real.

Ningun proveedor de esta lista se conecta de verdad en este bloque: cero
requests reales, cero creditos consumidos. Es preparacion conceptual para
cuando existan varios proveedores con capacidades distintas.

Punto F (UI provider-neutral): la UI normal del cliente NUNCA debe mostrar
"internal_label" — estos nombres son para uso interno/logs/futuro admin,
no para la pantalla que ve un tenant. voice_provider en la tabla agents
sigue siendo 'elevenlabs' por compatibilidad; eso no cambia.

Limites dinamicos de System Prompt / First Message (una sola fuente de
verdad, en vez de una constante fija duplicada en template y backend):

Cada motor declara su propio limite en 'system_prompt_limit' /
'first_message_limit', junto con un 'source' que dice de donde sale ese
numero:

  provider_confirmed  el proveedor lo documenta oficialmente en algun
                       lugar verificable — NO se usa todavia para ningun
                       motor porque no hay ninguna cifra confirmada dentro
                       del contexto de este proyecto (ver nota abajo).
  internal_default     limite de seguridad propio de la plataforma,
                       generoso pero no arbitrario (compatible con
                       MEDIUMTEXT, ver migracion 011) — se usa mientras no
                       exista una cifra confirmada del proveedor.

Nota importante: NO se inventa un numero de ElevenLabs/OpenAI/Fish Audio.
Si en el futuro se confirma un limite real y documentado de un proveedor,
se actualiza aca (system_prompt_limit + source='provider_confirmed') sin
tocar el backend ni la UI, que ya consumen esta funcion.
"""

# Limite de seguridad interno: generoso, compatible con MEDIUMTEXT
# (~16MB), muy por encima de cualquier prompt humano razonable. Nunca se
# presenta en la UI como si fuera un limite oficial de un proveedor.
INTERNAL_DEFAULT_SYSTEM_PROMPT_LIMIT = 100_000
INTERNAL_DEFAULT_FIRST_MESSAGE_LIMIT = 1_000  # ver justificacion en get_first_message_limit()

VOICE_ENGINES: dict[str, dict] = {
    "elevenlabs": {
        "internal_label": "ElevenLabs",  # NUNCA renderizar en UI normal del cliente
        "status": "available",
        "capabilities": ["conversational_agent", "tts", "multilingual"],
        "system_prompt_limit": INTERNAL_DEFAULT_SYSTEM_PROMPT_LIMIT,
        "system_prompt_limit_source": "internal_default",
        "first_message_limit": INTERNAL_DEFAULT_FIRST_MESSAGE_LIMIT,
        "first_message_limit_source": "internal_default",
    },
    "openai_realtime": {
        "internal_label": "OpenAI Realtime",
        "status": "planned",
        "capabilities": ["realtime_conversation", "voice"],
        "system_prompt_limit": INTERNAL_DEFAULT_SYSTEM_PROMPT_LIMIT,
        "system_prompt_limit_source": "internal_default",
        "first_message_limit": INTERNAL_DEFAULT_FIRST_MESSAGE_LIMIT,
        "first_message_limit_source": "internal_default",
    },
    "fish_audio": {
        "internal_label": "Fish Audio",
        "status": "planned",
        "capabilities": ["tts", "voice_clone", "streaming"],
        "system_prompt_limit": INTERNAL_DEFAULT_SYSTEM_PROMPT_LIMIT,
        "system_prompt_limit_source": "internal_default",
        "first_message_limit": INTERNAL_DEFAULT_FIRST_MESSAGE_LIMIT,
        "first_message_limit_source": "internal_default",
    },
}

# Unico motor aceptado como valor real en este bloque — el resto es
# metadata/planned, no algo que un tenant pueda elegir todavia.
DEFAULT_ENGINE = "elevenlabs"
ALLOWED_ENGINES = {DEFAULT_ENGINE}


def is_allowed_engine(key: str | None) -> bool:
    return key in ALLOWED_ENGINES


def get_system_prompt_limit(engine_id: str | None) -> dict:
    """{'limit': int, 'source': 'provider_confirmed'|'internal_default'}.
    Si el motor no esta en el catalogo (no deberia pasar tras validar con
    is_allowed_engine), cae al limite interno seguro — nunca a uno chico
    arbitrario, tal como exige la regla de este bloque."""
    meta = VOICE_ENGINES.get(engine_id or "")
    if not meta:
        return {"limit": INTERNAL_DEFAULT_SYSTEM_PROMPT_LIMIT, "source": "internal_default"}
    return {
        "limit": meta.get("system_prompt_limit", INTERNAL_DEFAULT_SYSTEM_PROMPT_LIMIT),
        "source": meta.get("system_prompt_limit_source", "internal_default"),
    }


def get_first_message_limit(engine_id: str | None) -> dict:
    """Mismo patron que get_system_prompt_limit(). El first_message es
    conceptualmente un saludo/apertura corto (no un prompt de
    instrucciones), por eso su default interno (1000) es mucho menor que
    el de system_prompt — no es un numero de proveedor, es una cota de
    sentido comun para lo que es una frase de apertura hablada."""
    meta = VOICE_ENGINES.get(engine_id or "")
    if not meta:
        return {"limit": INTERNAL_DEFAULT_FIRST_MESSAGE_LIMIT, "source": "internal_default"}
    return {
        "limit": meta.get("first_message_limit", INTERNAL_DEFAULT_FIRST_MESSAGE_LIMIT),
        "source": meta.get("first_message_limit_source", "internal_default"),
    }
