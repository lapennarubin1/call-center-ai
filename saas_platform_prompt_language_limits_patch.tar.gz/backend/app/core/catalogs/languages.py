"""Catalogo GLOBAL de idiomas — ISO 639-1 (Set 1, alpha-2) COMPLETO.

Vive en core/catalogs/ (no en modules/voice_ai/) porque es un catalogo
reutilizable por TODA la plataforma — Voice AI, CRM, WhatsApp AI, Chatbot,
Email AI, Automation y cualquier modulo futuro que necesite nombrar un
idioma. No tiene ningun acoplamiento a ElevenLabs, a Voice AI, ni a ningun
canal o proveedor especifico: es un dato puro, igual que un catalogo de
paises o de monedas.

Catalogo estatico centralizado (sin dependencia externa de runtime): 183
codigos actualmente asignados por ISO 639-1 (Set 1), tomados del listado
oficial en Wikipedia (List of ISO 639 language codes, columna "Set 1"),
que coincide con el conteo "183/676: Officially assigned" reportado ahi.
Se excluye "Hawaiian": en algunas tablas aparece con "haw" en la columna
Set 1, pero ISO 639-1 no le asigna codigo de 2 letras — solo tiene codigo
ISO 639-3 (alpha-3) "haw". Incluirlo violaria la regla de 2 letras del
catalogo.

Verificado programaticamente antes de este commit: 183 entradas, 183
codigos unicos, todos de 2 letras minusculas.

Tres capas separadas (calculo de disponibilidad final en UI = interseccion
de las tres, cuando exista sincronizacion real con providers):

  GLOBAL_LANGUAGES              este archivo — universo completo ISO 639-1
  MODULE_ENABLED_LANGUAGES      subset que cada modulo permite seleccionar
                                 hoy (ver voice_ai/languages.py para el de
                                 Voice AI)
  PROVIDER_SUPPORTED_LANGUAGES  futuro — que idiomas soporta realmente cada
                                 engine/provider externo (ver voice_engines.py,
                                 todavia sin sincronizacion real)

Ningun modulo debe mostrarle al usuario el catalogo global completo como
si todos esos idiomas estuvieran soportados por Voice AI (o por cualquier
otro modulo) — la UI consume siempre el subset habilitado del modulo, no
este archivo directamente.
"""

GLOBAL_LANGUAGES: dict[str, str] = {
    "aa": "Afar",
    "ab": "Abkhazian",
    "ae": "Avestan",
    "af": "Afrikaans",
    "ak": "Akan",
    "am": "Amharic",
    "an": "Aragonese",
    "ar": "Arabic",
    "as": "Assamese",
    "av": "Avaric",
    "ay": "Aymara",
    "az": "Azerbaijani",
    "ba": "Bashkir",
    "be": "Belarusian",
    "bg": "Bulgarian",
    "bi": "Bislama",
    "bm": "Bambara",
    "bn": "Bengali",
    "bo": "Tibetan",
    "br": "Breton",
    "bs": "Bosnian",
    "ca": "Catalan",
    "ce": "Chechen",
    "ch": "Chamorro",
    "co": "Corsican",
    "cr": "Cree",
    "cs": "Czech",
    "cu": "Church Slavonic",
    "cv": "Chuvash",
    "cy": "Welsh",
    "da": "Danish",
    "de": "German",
    "dv": "Divehi",
    "dz": "Dzongkha",
    "ee": "Ewe",
    "el": "Greek",
    "en": "English",
    "eo": "Esperanto",
    "es": "Spanish",
    "et": "Estonian",
    "eu": "Basque",
    "fa": "Persian",
    "ff": "Fulah",
    "fi": "Finnish",
    "fj": "Fijian",
    "fo": "Faroese",
    "fr": "French",
    "fy": "Western Frisian",
    "ga": "Irish",
    "gd": "Scottish Gaelic",
    "gl": "Galician",
    "gn": "Guarani",
    "gu": "Gujarati",
    "gv": "Manx",
    "ha": "Hausa",
    "he": "Hebrew",
    "hi": "Hindi",
    "ho": "Hiri Motu",
    "hr": "Croatian",
    "ht": "Haitian Creole",
    "hu": "Hungarian",
    "hy": "Armenian",
    "hz": "Herero",
    "ia": "Interlingua",
    "id": "Indonesian",
    "ie": "Interlingue",
    "ig": "Igbo",
    "ii": "Sichuan Yi",
    "ik": "Inupiaq",
    "io": "Ido",
    "is": "Icelandic",
    "it": "Italian",
    "iu": "Inuktitut",
    "ja": "Japanese",
    "jv": "Javanese",
    "ka": "Georgian",
    "kg": "Kongo",
    "ki": "Kikuyu",
    "kj": "Kuanyama",
    "kk": "Kazakh",
    "kl": "Kalaallisut",
    "km": "Khmer",
    "kn": "Kannada",
    "ko": "Korean",
    "kr": "Kanuri",
    "ks": "Kashmiri",
    "ku": "Kurdish",
    "kv": "Komi",
    "kw": "Cornish",
    "ky": "Kyrgyz",
    "la": "Latin",
    "lb": "Luxembourgish",
    "lg": "Ganda",
    "li": "Limburgish",
    "ln": "Lingala",
    "lo": "Lao",
    "lt": "Lithuanian",
    "lu": "Luba-Katanga",
    "lv": "Latvian",
    "mg": "Malagasy",
    "mh": "Marshallese",
    "mi": "Maori",
    "mk": "Macedonian",
    "ml": "Malayalam",
    "mn": "Mongolian",
    "mr": "Marathi",
    "ms": "Malay",
    "mt": "Maltese",
    "my": "Burmese",
    "na": "Nauru",
    "nb": "Norwegian Bokmal",
    "nd": "North Ndebele",
    "ne": "Nepali",
    "ng": "Ndonga",
    "nl": "Dutch",
    "nn": "Norwegian Nynorsk",
    "no": "Norwegian",
    "nr": "South Ndebele",
    "nv": "Navajo",
    "ny": "Chichewa",
    "oc": "Occitan",
    "oj": "Ojibwa",
    "om": "Oromo",
    "or": "Oriya",
    "os": "Ossetian",
    "pa": "Punjabi",
    "pi": "Pali",
    "pl": "Polish",
    "ps": "Pashto",
    "pt": "Portuguese",
    "qu": "Quechua",
    "rm": "Romansh",
    "rn": "Rundi",
    "ro": "Romanian",
    "ru": "Russian",
    "rw": "Kinyarwanda",
    "sa": "Sanskrit",
    "sc": "Sardinian",
    "sd": "Sindhi",
    "se": "Northern Sami",
    "sg": "Sango",
    "si": "Sinhala",
    "sk": "Slovak",
    "sl": "Slovenian",
    "sm": "Samoan",
    "sn": "Shona",
    "so": "Somali",
    "sq": "Albanian",
    "sr": "Serbian",
    "ss": "Swati",
    "st": "Southern Sotho",
    "su": "Sundanese",
    "sv": "Swedish",
    "sw": "Swahili",
    "ta": "Tamil",
    "te": "Telugu",
    "tg": "Tajik",
    "th": "Thai",
    "ti": "Tigrinya",
    "tk": "Turkmen",
    "tl": "Tagalog",
    "tn": "Tswana",
    "to": "Tonga",
    "tr": "Turkish",
    "ts": "Tsonga",
    "tt": "Tatar",
    "tw": "Twi",
    "ty": "Tahitian",
    "ug": "Uighur",
    "uk": "Ukrainian",
    "ur": "Urdu",
    "uz": "Uzbek",
    "ve": "Venda",
    "vi": "Vietnamese",
    "vo": "Volapuk",
    "wa": "Walloon",
    "wo": "Wolof",
    "xh": "Xhosa",
    "yi": "Yiddish",
    "yo": "Yoruba",
    "za": "Zhuang",
    "zh": "Chinese",
    "zu": "Zulu",
}


def is_valid_language(code: str | None) -> bool:
    return bool(code) and code in GLOBAL_LANGUAGES


def language_label(code: str | None) -> str:
    return GLOBAL_LANGUAGES.get(code or "", code or "\u2014")


def language_choices() -> list[tuple[str, str]]:
    """[(codigo, etiqueta), ...] ordenados alfabeticamente por etiqueta."""
    return sorted(GLOBAL_LANGUAGES.items(), key=lambda kv: kv[1])
