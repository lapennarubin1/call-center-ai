-- 008_voice_campaigns_extend.sql
-- Extension ADITIVA de voice_campaigns para soportar el CRUD de campanas.
-- No modifica 001-007. No borra ni renombra ninguna columna existente.
--
-- 1) description: el formulario de creacion/edicion pide una descripcion
--    opcional que hoy no existe en el esquema.
-- 2) status: se agrega 'archived' al ENUM. Los valores existentes
--    ('draft','active','paused','finished') se preservan intactos; ninguna
--    fila actual cambia de valor. 'active' sigue sin usarse desde este
--    bloque (no se permite crear/editar hacia 'active' todavia).

ALTER TABLE voice_campaigns
  ADD COLUMN description TEXT NULL AFTER name;

ALTER TABLE voice_campaigns
  MODIFY COLUMN status ENUM('draft','active','paused','archived','finished')
  NOT NULL DEFAULT 'draft';
