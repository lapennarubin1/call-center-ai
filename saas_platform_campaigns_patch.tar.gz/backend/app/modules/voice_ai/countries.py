"""Catalogo de paises soportados por Voice AI.

Diseñado para ampliarse sin reescribir la logica que lo consume: agregar un
pais nuevo es agregar una entrada a SUPPORTED_COUNTRIES, nada mas — ni las
rutas de campanas ni los templates necesitan cambiar. Si en el futuro esto
necesita vivir en base de datos (self-service por tenant), este modulo es
el unico punto que se reemplaza.

country se guarda en voice_campaigns.country como ISO-3166-1 alpha-2
(columna ya definida asi desde Documento 11 / Sprint 1) — mismo formato que
ya usa sip_provider_pricing en la base asterisk, sin inventar un formato
nuevo.
"""

SUPPORTED_COUNTRIES: dict[str, dict] = {
    "MX": {"label": "Mexico", "timezone": "America/Mexico_City"},
    "IN": {"label": "India", "timezone": "Asia/Kolkata"},
    "AE": {"label": "Dubai / UAE", "timezone": "Asia/Dubai"},
}


def is_valid_country(code: str | None) -> bool:
    return bool(code) and code.upper() in SUPPORTED_COUNTRIES


def country_choices() -> list[tuple[str, str]]:
    """[(codigo, etiqueta), ...] en el orden declarado, para selects."""
    return [(code, meta["label"]) for code, meta in SUPPORTED_COUNTRIES.items()]


def country_label(code: str | None) -> str:
    meta = SUPPORTED_COUNTRIES.get((code or "").upper())
    return meta["label"] if meta else (code or "—")


def default_timezone(code: str) -> str | None:
    meta = SUPPORTED_COUNTRIES.get((code or "").upper())
    return meta["timezone"] if meta else None
