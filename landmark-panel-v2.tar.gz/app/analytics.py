"""
Analytics engine — Landmark Markets Control Panel
====================================================
All telephony and commercial funnel metrics.

SQL portable: funciona igual en MySQL (producción) y SQLite (tests).
Los rangos de fecha se pasan como parámetros Python, nunca con DATE_SUB,
para no depender de dialecto.

COSTO: se factura por minuto completo redondeado hacia arriba POR LLAMADA
       -> SUM(CEIL(billsec/60.0)), consistente con /root/menu.sh
"""
from datetime import datetime, timedelta, date
import calendar, time, threading, hashlib, json

DEFAULT_RATE = 0.06   # USD por minuto
TZ_SHIFT_MIN = 330    # UTC → IST (+5:30).

# ══════════════════════════════════════════════════════════════════
#  IST — eje horario único de todo el panel
#  ────────────────────────────────────────────────────────────────
#  El VPS guarda todo en UTC (CDR de Asterisk, y los timestamps que
#  WF14 normaliza desde Google Sheets). El negocio opera en India.
#  Si comparáramos "hoy/ayer" contra medianoche UTC, una cuenta
#  abierta a la 1am IST queda registrada como las 19:30 UTC del día
#  ANTERIOR — y desaparece del período que el usuario espera verla.
#
#  Regla aplicada en TODO el módulo, sin excepciones:
#  - Los límites de período (resolve_range) se calculan en hora IST.
#  - Toda columna de fecha se compara/agrupa con esa MISMA columna
#    desplazada +5:30 vía ist_expr(), nunca cruda.
#  - now_ist() reemplaza a datetime.now() en cualquier lugar donde
#    el panel muestre o calcule "ahora".
# ══════════════════════════════════════════════════════════════════
IST_DELTA = timedelta(minutes=TZ_SHIFT_MIN)


def now_ist():
    """'Ahora' en hora de India, sin depender de la zona horaria del VPS."""
    return datetime.utcnow() + IST_DELTA


def to_ist(dt_utc):
    """Convierte un datetime naive-UTC (ej. de MySQL) a hora IST para mostrar."""
    if dt_utc is None:
        return None
    if isinstance(dt_utc, str):
        try:
            dt_utc = datetime.strptime(dt_utc[:19], '%Y-%m-%d %H:%M:%S')
        except ValueError:
            return None
    return dt_utc + IST_DELTA


def ist_expr(db, col):
    """
    Expresión SQL que desplaza una columna UTC a hora IST — SOLO para
    GROUP BY o extracción de hora, donde no hay forma de usar el índice
    de todos modos. Para WHERE, usar utc_bounds() en su lugar: envolver
    la columna en DATE_ADD/datetime() en el WHERE impide que el motor
    use el índice de calldate y fuerza un escaneo completo de la tabla.
    """
    if db.driver == 'mysql':
        return f"DATE_ADD({col}, INTERVAL {TZ_SHIFT_MIN} MINUTE)"
    return f"datetime({col}, '+{TZ_SHIFT_MIN} minutes')"


def utc_bounds(s, e):
    """
    Convierte un rango IST (el que devuelve resolve_range) a UTC para
    comparar directo contra la columna cruda — así el motor SÍ puede
    usar el índice de calldate/last_call_time/created_at. Es el mismo
    desplazamiento que ist_expr(), aplicado al límite en vez de a cada
    fila de la tabla: mismo resultado, sin escaneo completo.
    """
    return _f(s - IST_DELTA), _f(e - IST_DELTA)


# ══════════════════════════════════════════════════════════════════
#  Caché TTL — los rangos largos (año) agregan cientos de miles de
#  filas; sin caché cada refresco del navegador re-ejecuta todo.
# ══════════════════════════════════════════════════════════════════
class TTLCache:
    def __init__(self, ttl=60):
        self.ttl = ttl
        self._d = {}
        self._lock = threading.Lock()

    def key(self, *parts):
        return hashlib.md5(json.dumps(parts, default=str).encode()).hexdigest()

    def get(self, k):
        with self._lock:
            v = self._d.get(k)
            if v and time.time() - v[0] < self.ttl:
                return v[1]
            if v:
                del self._d[k]
        return None

    def set(self, k, val):
        with self._lock:
            if len(self._d) > 200:            # poda simple
                oldest = sorted(self._d.items(), key=lambda x: x[1][0])[:100]
                for ok, _ in oldest:
                    del self._d[ok]
            self._d[k] = (time.time(), val)
        return val

    def clear(self):
        with self._lock:
            self._d.clear()


CACHE = TTLCache(ttl=60)


# ══════════════════════════════════════════════════════════════════
#  Capa de acceso a datos (abstrae MySQL vs SQLite)
# ══════════════════════════════════════════════════════════════════
class DB:
    def __init__(self, conn, driver):
        self.conn = conn
        self.driver = driver          # 'mysql' | 'sqlite'
        self.ph = '%s' if driver == 'mysql' else '?'

    def q(self, sql, params=()):
        """Ejecuta y devuelve lista de dicts."""
        sql = sql.replace('§', self.ph)
        cur = self.conn.cursor()
        cur.execute(sql, params)
        cols = [d[0] for d in cur.description]
        out = [dict(zip(cols, row)) for row in cur.fetchall()]
        cur.close()
        return out

    def one(self, sql, params=()):
        r = self.q(sql, params)
        return r[0] if r else {}

    def table_exists(self, name):
        try:
            self.q(f"SELECT 1 FROM {name} LIMIT 1")
            return True
        except Exception:
            return False


# ══════════════════════════════════════════════════════════════════
#  Helpers de rango de fechas
# ══════════════════════════════════════════════════════════════════
def resolve_range(period, ref=None, start=None, end=None):
    """
    Devuelve (start_dt, end_dt, label, prev_start, prev_end).
    El rango es [start, end) — end exclusivo.

    IMPORTANTE: s/e quedan expresados como hora IST "naive" (sin
    convertir a UTC acá). Cada consulta SQL es la que se encarga de
    desplazar su propia columna con ist_expr() antes de comparar —
    así el límite se calcula una sola vez y nunca se duplica el
    desplazamiento por accidente.
    """
    ref = ref or now_ist()
    today = ref.replace(hour=0, minute=0, second=0, microsecond=0)

    if period == 'custom' and start and end:
        s = datetime.strptime(start, '%Y-%m-%d')
        e = datetime.strptime(end, '%Y-%m-%d') + timedelta(days=1)
        label = f"{s:%d/%m/%Y} – {(e - timedelta(days=1)):%d/%m/%Y}"
    elif period == 'today':
        s, e = today, today + timedelta(days=1)
        label = f"Today · {s:%d/%m/%Y}"
    elif period == 'yesterday':
        s, e = today - timedelta(days=1), today
        label = f"Yesterday · {s:%d/%m/%Y}"
    elif period == 'week':
        s = today - timedelta(days=today.weekday())        # lunes
        e = s + timedelta(days=7)
        label = f"Week · {s:%d/%m} – {(e - timedelta(days=1)):%d/%m/%Y}"
    elif period == 'month':
        s = today.replace(day=1)
        last = calendar.monthrange(s.year, s.month)[1]
        e = s.replace(day=last) + timedelta(days=1)
        label = f"Month · {s:%B %Y}"
    elif period == 'year':
        s = today.replace(month=1, day=1)
        e = s.replace(year=s.year + 1)
        label = f"Year · {s.year}"
    elif period == 'last7':
        s, e = today - timedelta(days=6), today + timedelta(days=1)
        label = "Last 7 days"
    elif period == 'last30':
        s, e = today - timedelta(days=29), today + timedelta(days=1)
        label = "Last 30 days"
    elif period == 'last90':
        s, e = today - timedelta(days=89), today + timedelta(days=1)
        label = "Last 90 days"
    else:
        s, e = today, today + timedelta(days=1)
        label = f"Today · {s:%d/%m/%Y}"

    span = e - s
    prev_s, prev_e = s - span, s
    return s, e, label, prev_s, prev_e


def _f(dt):
    return dt.strftime('%Y-%m-%d %H:%M:%S')


def pct(part, whole):
    return round(part / whole * 100, 2) if whole else 0.0


def delta(cur, prev):
    """Variación % contra el período anterior."""
    if not prev:
        return None
    return round((cur - prev) / prev * 100, 1)


# ══════════════════════════════════════════════════════════════════
#  MÉTRICAS DE TELEFONÍA (fuente: CDR de Asterisk)
# ══════════════════════════════════════════════════════════════════
def _traffic_sql(db):
    # WHERE sin envolver la columna: usa el índice de calldate.
    # Los límites ya vienen convertidos a UTC por utc_bounds().
    return """
SELECT
    COUNT(*)                                                        AS total_calls,
    SUM(CASE WHEN disposition='ANSWERED'   THEN 1 ELSE 0 END)       AS answered,
    SUM(CASE WHEN disposition='NO ANSWER'  THEN 1 ELSE 0 END)       AS no_answer,
    SUM(CASE WHEN disposition='BUSY'       THEN 1 ELSE 0 END)       AS busy,
    SUM(CASE WHEN disposition='FAILED'     THEN 1 ELSE 0 END)       AS failed,
    SUM(CASE WHEN disposition='CONGESTION' THEN 1 ELSE 0 END)       AS congestion,
    COALESCE(SUM(CEIL(billsec/60.0)), 0)                            AS billed_minutes,
    COALESCE(SUM(billsec), 0)                                       AS talk_seconds,
    COALESCE(MAX(billsec), 0)                                       AS longest_call
FROM cdr
WHERE calldate >= § AND calldate < §
"""


def _int(v):
    """Convierte int, float o Decimal (MariaDB) a int de Python."""
    try:    return int(v) if v is not None else 0
    except Exception: return 0

def _float(v):
    """Convierte int, float o Decimal (MariaDB) a float de Python."""
    try:    return float(v) if v is not None else 0.0
    except Exception: return 0.0

def traffic(db, s, e, rate=DEFAULT_RATE):
    r = db.one(_traffic_sql(db), utc_bounds(s, e))
    total     = _int(r.get('total_calls'))
    answered  = _int(r.get('answered'))
    no_answer = _int(r.get('no_answer'))
    busy      = _int(r.get('busy'))
    failed    = _int(r.get('failed'))
    cong      = _int(r.get('congestion'))
    minutes   = _int(r.get('billed_minutes'))
    talk      = _int(r.get('talk_seconds'))

    cost = round(minutes * rate, 2)
    # ASR = Answer Seizure Ratio — % de intentos que terminan en conversación
    asr = pct(answered, total)
    # NER = Network Effectiveness Ratio — salud de la red: descarta solo fallos técnicos
    ner = pct(answered + no_answer + busy, total)
    # ACD = Average Call Duration (sobre contestadas)
    acd = round(talk / answered, 1) if answered else 0.0

    return {
        'total_calls'    : total,
        'answered'       : answered,
        'no_answer'      : no_answer,
        'busy'           : busy,
        'failed'         : failed,
        'congestion'     : cong,
        'tech_failures'  : failed + cong,
        'billed_minutes' : minutes,
        'talk_seconds'   : talk,
        'talk_minutes'   : round(talk / 60, 1),
        'longest_call'   : int(r.get('longest_call') or 0),
        'cost'           : cost,
        'asr'            : asr,
        'ner'            : ner,
        'acd'            : acd,
        'answer_rate'    : asr,
        'no_answer_rate' : pct(no_answer, total),
        'failure_rate'   : pct(failed + cong, total),
        'cost_per_answered': round(cost / answered, 4) if answered else 0.0,
        'cost_per_call'  : round(cost / total, 4) if total else 0.0,
        'avg_min_per_call': round(minutes / total, 2) if total else 0.0,
    }


def timeseries(db, s, e, grain='day', rate=DEFAULT_RATE):
    """
    grain: hour | day | week | month — todo agrupado en calendario IST.
    Antes esto agrupaba por la columna cruda (UTC): una llamada de las
    23:50 IST podía aparecer bajo el día equivocado o la hora corrida.
    Ahora se agrupa sobre la MISMA columna ya desplazada a IST.
    """
    # GROUP BY sí necesita la columna desplazada (no hay índice que
    # ayude a agrupar de todos modos). El WHERE usa la columna cruda
    # con límites ya convertidos a UTC — así sí aprovecha el índice.
    ist_col = ist_expr(db, 'calldate')
    if db.driver == 'mysql':
        bucket = {
            'hour' : f"DATE_FORMAT({ist_col},'%%Y-%%m-%%d %%H:00')",
            'day'  : f"DATE_FORMAT({ist_col},'%%Y-%%m-%%d')",
            'week' : f"DATE_FORMAT({ist_col},'%%x-W%%v')",
            'month': f"DATE_FORMAT({ist_col},'%%Y-%%m')",
        }[grain]
    else:
        bucket = {
            'hour' : f"strftime('%Y-%m-%d %H:00', {ist_col})",
            'day'  : f"strftime('%Y-%m-%d', {ist_col})",
            'week' : f"strftime('%Y-W%W', {ist_col})",
            'month': f"strftime('%Y-%m', {ist_col})",
        }[grain]

    sql = f"""
SELECT
    {bucket}                                                  AS bucket,
    COUNT(*)                                                  AS total_calls,
    SUM(CASE WHEN disposition='ANSWERED' THEN 1 ELSE 0 END)   AS answered,
    SUM(CASE WHEN disposition='NO ANSWER' THEN 1 ELSE 0 END)  AS no_answer,
    SUM(CASE WHEN disposition IN ('FAILED','CONGESTION') THEN 1 ELSE 0 END) AS failed,
    COALESCE(SUM(CEIL(billsec/60.0)), 0)                      AS billed_minutes,
    COALESCE(SUM(billsec), 0)                                 AS talk_seconds
FROM cdr
WHERE calldate >= § AND calldate < §
GROUP BY bucket
ORDER BY bucket
"""
    rows = db.q(sql, utc_bounds(s, e))
    for r in rows:
        r['total_calls']    = _int(r.get('total_calls'))
        r['answered']       = _int(r.get('answered'))
        r['no_answer']      = _int(r.get('no_answer'))
        r['failed']         = _int(r.get('failed'))
        r['billed_minutes'] = _int(r.get('billed_minutes'))
        r['talk_seconds']   = _int(r.get('talk_seconds'))
        r['cost']    = round(r['billed_minutes'] * rate, 2)
        r['asr']     = pct(r['answered'], r['total_calls'])
        r['acd']     = round(r['talk_seconds'] / r['answered'], 1) if r['answered'] else 0.0
    return rows


def _hourly_sql(db, hour_expr):
    # WHERE con la columna cruda (usa índice); solo hour_expr desplaza.
    return f"""
SELECT
    {hour_expr}                                               AS hh,
    COUNT(*)                                                  AS total_calls,
    SUM(CASE WHEN disposition='ANSWERED' THEN 1 ELSE 0 END)   AS answered,
    COALESCE(SUM(CEIL(billsec/60.0)), 0)                      AS billed_minutes
FROM cdr
WHERE calldate >= § AND calldate < §
GROUP BY hh
ORDER BY hh
"""


def hourly_profile(db, s, e, rate=DEFAULT_RATE, tz_shift_min=TZ_SHIFT_MIN):
    """
    Distribución por hora en horario LOCAL de la operación (IST).

    El CDR de Asterisk guarda la hora del servidor (UTC). India es UTC+5:30,
    por eso desplazamos el timestamp COMPLETO antes de extraer la hora —
    si extrajéramos la hora primero perderíamos los 30 minutos del offset
    y todo el perfil quedaría corrido una hora hacia atrás.

    El WHERE externo usa la MISMA columna desplazada (antes comparaba
    contra la hora cruda mientras s/e ya venían en IST — desalineado).
    """
    if db.driver == 'mysql':
        hour_expr = f"HOUR(DATE_ADD(calldate, INTERVAL {tz_shift_min} MINUTE))"
    else:
        hour_expr = f"CAST(strftime('%H', datetime(calldate, '+{tz_shift_min} minutes')) AS INTEGER)"

    rows = db.q(_hourly_sql(db, hour_expr), utc_bounds(s, e))

    buckets = {h: {'hour': h, 'total_calls': 0, 'answered': 0,
                   'billed_minutes': 0, 'asr': 0.0, 'cost': 0.0} for h in range(24)}
    for r in rows:
        b = buckets[int(r['hh']) % 24]
        b['total_calls']   += _int(r.get('total_calls'))
        b['answered']      += _int(r.get('answered'))
        b['billed_minutes']+= _int(r.get('billed_minutes'))
    for b in buckets.values():
        b['asr']  = pct(b['answered'], b['total_calls'])
        b['cost'] = round(b['billed_minutes'] * rate, 2)
    return [buckets[h] for h in range(24)]


def _duration_sql(db):
    return "SELECT billsec FROM cdr WHERE calldate >= § AND calldate < § AND disposition='ANSWERED'"


def duration_buckets(db, s, e):
    """
    Duration distribution of answered calls.
    Clave para el negocio: separa 'atendió y colgó' de 'real conversation'.
    """
    rows = db.q(_duration_sql(db), utc_bounds(s, e))
    edges = [(0, 10, '0–10s'), (10, 30, '10–30s'), (30, 60, '30–60s'),
             (60, 120, '1–2min'), (120, 300, '2–5min'), (300, 10**9, '+5min')]
    out = [{'label': lbl, 'count': 0, 'lo': lo, 'hi': hi} for lo, hi, lbl in edges]
    total = 0
    for r in rows:
        b = r['billsec'] or 0
        total += 1
        for i, (lo, hi, _) in enumerate(edges):
            if lo <= b < hi:
                out[i]['count'] += 1
                break
    for o in out:
        o['pct'] = pct(o['count'], total)
    # "Real conversation" = 30s or more (below that is almost always an immediate hang-up)
    meaningful = sum(o['count'] for o in out if o['lo'] >= 30)
    return {'buckets': out, 'total': total, 'meaningful': meaningful,
            'meaningful_pct': pct(meaningful, total)}


def _top_numbers_sql(db):
    return """
SELECT dst,
       COUNT(*)                                                AS attempts,
       SUM(CASE WHEN disposition='ANSWERED' THEN 1 ELSE 0 END) AS answered,
       COALESCE(SUM(billsec),0)                                AS talk_seconds,
       MAX(calldate)                                           AS last_attempt
FROM cdr
WHERE calldate >= § AND calldate < §
GROUP BY dst
HAVING answered > 0
ORDER BY talk_seconds DESC
LIMIT §
"""


def top_conversations(db, s, e, limit=15):
    bs, be = utc_bounds(s, e)
    rows = db.q(_top_numbers_sql(db), (bs, be, limit))
    for r in rows:
        r['talk_minutes'] = round((r['talk_seconds'] or 0) / 60, 1)
        r['last_attempt_ist'] = to_ist(r.get('last_attempt'))
    return rows


def _repeat_sql(db):
    return """
SELECT attempts, COUNT(*) AS numbers FROM (
    SELECT dst, COUNT(*) AS attempts
    FROM cdr WHERE calldate >= § AND calldate < §
    GROUP BY dst
) t GROUP BY attempts ORDER BY attempts
"""


def retry_distribution(db, s, e):
    """Cuántos números recibieron 1, 2, 3+ intentos — measures dialer efficiency."""
    rows = db.q(_repeat_sql(db), utc_bounds(s, e))
    total_numbers = sum(r['numbers'] for r in rows)
    out = []
    for r in rows:
        if r['attempts'] >= 4:
            continue
        out.append({'attempts': r['attempts'], 'numbers': r['numbers'],
                    'pct': pct(r['numbers'], total_numbers)})
    plus4 = sum(r['numbers'] for r in rows if r['attempts'] >= 4)
    if plus4:
        out.append({'attempts': '4+', 'numbers': plus4, 'pct': pct(plus4, total_numbers)})
    return {'rows': out, 'unique_numbers': total_numbers}


# ══════════════════════════════════════════════════════════════════
#  MÉTRICAS DE EMBUDO COMERCIAL (fuente: panel_leads / panel_conversions)
# ══════════════════════════════════════════════════════════════════
FINAL_STATES = ('SUCCESSFUL', 'INTERESTED', 'CONVERTED', 'VOICEMAIL',
                'FAILED', 'SCHEDULED', 'NO_ANSWER', 'DO_NOT_CALL',
                'SALES_HANDOFF', 'NOT_INTERESTED')

# Explica qué significa cada status y qué evalúa el sistema para
# ponerlo — se muestra como tooltip al pasar el mouse en el panel.
STATUS_DESCRIPTIONS = {
    'READY_TO_CALL'       : 'Waiting in queue. WF2 has not dialed this lead yet.',
    'DIALING'              : 'WF2 just sent this call to ElevenLabs — resolves in seconds.',
    'CALL_IN_PROGRESS'     : 'ElevenLabs accepted the call and it is ringing or in conversation right now.',
    'NO_ANSWER'            : 'The phone rang but nobody picked up.',
    'VOICEMAIL'            : 'An answering machine picked up instead of a real person.',
    'FAILED'               : 'The call could not connect — carrier or network issue, not the phone number.',
    'DIAL_FAILED'          : 'The dial attempt itself failed before it could ring.',
    'SUCCESSFUL'           : 'A person answered and had a real conversation with the agent.',
    'SCHEDULED'            : 'The lead asked to be called back at a specific time. WF4 handles the callback.',
    'INTERESTED'           : 'WF3 confirmed this only when a real Atlantis account was actually opened — not guessed from the conversation.',
    'CONVERTED'            : 'The account is open and the client is active.',
    'SALES_HANDOFF'        : 'Escalated to a human sales agent instead of continuing automated calls.',
    'NOT_INTERESTED'       : 'The lead explicitly said they are not interested.',
    'DO_NOT_CALL'          : 'The lead asked to never be called again — permanently excluded from WF2.',
    'MAX_ATTEMPTS_REACHED' : 'WF2 tried 3 times with no result and stopped — needs manual review.',
    'INVALID_LEAD'         : 'The phone number or lead data was invalid and could not be dialed.',
}


def funnel(db, s, e, traffic_stats=None, rate=DEFAULT_RATE):
    """
    Embudo comercial. Devuelve dict vacío si las tablas del panel
    todavía no fueron sincronizadas (WF14) — el panel no se rompe.
    """
    if not db.table_exists('panel_leads'):
        return {'available': False}

    by_status = db.q("""
        SELECT status, COUNT(*) AS n
        FROM panel_leads
        WHERE last_call_time >= § AND last_call_time < §
        GROUP BY status ORDER BY n DESC
    """, utc_bounds(s, e))

    total_touched = sum(r['n'] for r in by_status)
    d = {r['status']: r['n'] for r in by_status}

    contacted   = d.get('SUCCESSFUL', 0) + d.get('INTERESTED', 0) + d.get('CONVERTED', 0)
    voicemail   = d.get('VOICEMAIL', 0)
    no_answer   = d.get('NO_ANSWER', 0)
    scheduled   = d.get('SCHEDULED', 0)
    interested  = d.get('INTERESTED', 0) + d.get('CONVERTED', 0)

    accounts = 0
    if db.table_exists('panel_conversions'):
        r = db.one("""SELECT COUNT(*) AS n FROM panel_conversions
                      WHERE created_at >= § AND created_at < §""", utc_bounds(s, e))
        accounts = r.get('n') or 0

    cost = (traffic_stats or {}).get('cost', 0.0)
    answered = (traffic_stats or {}).get('answered', 0)

    return {
        'available'        : True,
        'by_status'        : by_status,
        'total_touched'    : total_touched,
        'contacted'        : contacted,
        'voicemail'        : voicemail,
        'no_answer'        : no_answer,
        'scheduled'        : scheduled,
        'interested'       : interested,
        'accounts_opened'  : accounts,
        'contact_rate'     : pct(contacted, total_touched),
        'conversion_rate'  : pct(accounts, contacted),
        'lead_to_account'  : pct(accounts, total_touched),
        'cpa'              : round(cost / accounts, 2) if accounts else 0.0,
        'cost_per_contact' : round(cost / contacted, 2) if contacted else 0.0,
        'callback_rate'    : pct(scheduled, contacted),
    }


def pipeline_snapshot(db, s=None, e=None):
    """
    Estado del pipeline de leads.

    Si se pasan s/e, filtra por last_call_time dentro de ese período
    (mismo criterio que funnel(), sincronizado con el selector de
    fechas). "In progress now" y "Pending calls" en cambio muestran
    SIEMPRE el estado actual real — son conceptos de "ahora mismo",
    no de "qué pasó en tal período": no tendría sentido que la cola
    de pendientes cambie según qué rango de fechas estés mirando.
    """
    if not db.table_exists('panel_leads'):
        return {'available': False}

    if s is not None and e is not None:
        rows = db.q("""
            SELECT status, COUNT(*) AS n FROM panel_leads
            WHERE last_call_time >= § AND last_call_time < §
            GROUP BY status ORDER BY n DESC
        """, utc_bounds(s, e))
        scoped = True
    else:
        rows = db.q("SELECT status, COUNT(*) AS n FROM panel_leads GROUP BY status ORDER BY n DESC")
        scoped = False

    total = sum(r['n'] for r in rows)
    for r in rows:
        r['pct'] = pct(r['n'], total)
        r['description'] = STATUS_DESCRIPTIONS.get((r['status'] or '').upper(), '')

    # Siempre el total actual, sin filtrar — son colas operativas "ahora mismo"
    cur = db.q("SELECT status, COUNT(*) AS n FROM panel_leads GROUP BY status")
    cd = {r['status']: r['n'] for r in cur}

    return {
        'available'   : True,
        'scoped'      : scoped,
        'rows'        : rows,
        'total'       : total,
        'pending'     : cd.get('READY_TO_CALL', 0),
        'in_flight'   : cd.get('CALL_IN_PROGRESS', 0) + cd.get('DIALING', 0),
        'exhausted'   : cd.get('MAX_ATTEMPTS_REACHED', 0),
        'do_not_call' : cd.get('DO_NOT_CALL', 0),
    }


def conversions_list(db, s, e, limit=100):
    if not db.table_exists('panel_conversions'):
        return []
    bs, be = utc_bounds(s, e)
    rows = db.q("""
        SELECT lead_id, full_name, phone, atlantis_user, account_id, created_at
        FROM panel_conversions
        WHERE created_at >= § AND created_at < §
        ORDER BY created_at DESC LIMIT §
    """, (bs, be, limit))
    for r in rows:
        ist_dt = to_ist(r.get('created_at'))
        r['created_at_ist'] = ist_dt.strftime('%Y-%m-%d %H:%M:%S') if ist_dt else ''
    return rows


# ══════════════════════════════════════════════════════════════════
#  ENSAMBLADO COMPLETO
# ══════════════════════════════════════════════════════════════════
def sync_status(db):
    """
    Frescura de los datos de leads. Si WF14 deja de correr, el panel
    seguiría mostrando cifras viejas como si fueran de hoy — esto lo
    hace visible en vez de silencioso.
    """
    if not db.table_exists('panel_sync_log'):
        # Sin bitácora, caemos al sello de la propia tabla de leads
        if not db.table_exists('panel_leads'):
            return {'available': False}
        r = db.one("SELECT MAX(synced_at) AS last FROM panel_leads")
    else:
        r = db.one("SELECT MAX(synced_at) AS last FROM panel_sync_log")

    last = r.get('last')
    if not last:
        return {'available': True, 'ever': False, 'stale': True, 'last': None, 'age_min': None}

    if isinstance(last, str):
        try:
            last = datetime.strptime(last[:19], '%Y-%m-%d %H:%M:%S')
        except ValueError:
            return {'available': True, 'ever': False, 'stale': True, 'last': None, 'age_min': None}

    age = (now_ist() - to_ist(last)).total_seconds() / 60
    return {
        'available': True, 'ever': True,
        'last': to_ist(last).strftime('%d/%m %H:%M') + ' IST',
        'age_min': int(age),
        # WF14 corre cada 15 min; a partir de 45 hay algo mal
        'stale': age > 45,
    }


def build_report(db, period='today', start=None, end=None,
                 rate=DEFAULT_RATE, ref=None, use_cache=True):
    ck = CACHE.key('report', period, start, end, rate)
    if use_cache:
        hit = CACHE.get(ck)
        if hit is not None:
            return hit

    s, e, label, ps, pe = resolve_range(period, ref, start, end)

    cur  = traffic(db, s, e, rate)
    prev = traffic(db, ps, pe, rate)

    # Granularidad automática según el largo del rango
    span_days = (e - s).days
    grain = 'hour' if span_days <= 2 else 'day' if span_days <= 92 else 'month'

    fn = funnel(db, s, e, cur, rate)

    report = {
        'label'      : label,
        'period'     : period,
        'range'      : {'start': s.strftime('%Y-%m-%d'),
                        'end'  : (e - timedelta(days=1)).strftime('%Y-%m-%d')},
        'rate'       : rate,
        'traffic'    : cur,
        'deltas'     : {
            'total_calls'   : delta(cur['total_calls'],   prev['total_calls']),
            'answered'      : delta(cur['answered'],      prev['answered']),
            'cost'          : delta(cur['cost'],          prev['cost']),
            'billed_minutes': delta(cur['billed_minutes'],prev['billed_minutes']),
            'asr'           : delta(cur['asr'],           prev['asr']),
            'acd'           : delta(cur['acd'],           prev['acd']),
        },
        'previous'   : prev,
        'series'     : timeseries(db, s, e, grain, rate),
        'grain'      : grain,
        'hourly'     : hourly_profile(db, s, e, rate),
        'durations'  : duration_buckets(db, s, e),
        'top_calls'  : top_conversations(db, s, e),
        'retries'    : retry_distribution(db, s, e),
        'funnel'     : fn,
        'pipeline'   : pipeline_snapshot(db, s, e),
        'sync'       : sync_status(db),
        'generated'  : now_ist().strftime('%Y-%m-%d %H:%M:%S') + ' IST',
    }
    return CACHE.set(ck, report) if use_cache else report
