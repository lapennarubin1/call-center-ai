"""
Prueba dedicada al bug reportado: una cuenta abierta pasada la
medianoche IST (pero AÚN el mismo día calendario UTC anterior)
tiene que aparecer en el período correcto según hora de India,
no según hora del servidor.

Caso real: cuenta abierta 07/08 a las 00:20 IST.
En UTC eso es 06/08 18:50 — un motor que compare por día UTC la
metería en "06/08", pero para el usuario (India) es claramente "07/08".
"""
import sqlite3, os, sys
from datetime import datetime, timedelta

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from app.analytics import (DB, resolve_range, funnel, conversions_list,
                           traffic, now_ist, to_ist, IST_DELTA)

FAIL = []
def check(name, cond, detail=''):
    if not cond: FAIL.append(name)
    print(f"  [{'OK  ' if cond else 'FAIL'}] {name}" + (f'  → {detail}' if detail else ''))


conn = sqlite3.connect(':memory:')
c = conn.cursor()
c.execute("""CREATE TABLE cdr (
    calldate DATETIME, clid TEXT, src TEXT, dst TEXT, dcontext TEXT,
    channel TEXT, dstchannel TEXT, lastapp TEXT, lastdata TEXT,
    duration INT, billsec INT, disposition TEXT, amaflags INT,
    accountcode TEXT, uniqueid TEXT, userfield TEXT)""")
c.execute("""CREATE TABLE panel_leads (
    lead_id TEXT PRIMARY KEY, full_name TEXT, phone TEXT, country TEXT,
    language TEXT, status TEXT, last_call_status TEXT, call_attempts INT,
    last_call_time DATETIME, duration_secs INT, synced_at DATETIME)""")
c.execute("""CREATE TABLE panel_conversions (
    lead_id TEXT PRIMARY KEY, full_name TEXT, phone TEXT,
    atlantis_user TEXT, account_id TEXT, created_at DATETIME, synced_at DATETIME)""")

db = DB(conn, 'sqlite')

# ═══ El caso exacto reportado ═══
# "Hoy" simulado: 07/08/2026, mirado desde algún momento de ese día IST.
# ref_ist representa el instante "ahora" en IST.
ref_ist = datetime(2026, 8, 7, 15, 0, 0)   # 3pm IST del 7 de agosto

# Cuenta abierta a las 00:20 IST del 07/08 → en UTC es 06/08 18:50
account_time_ist = datetime(2026, 8, 7, 0, 20, 0)
account_time_utc = account_time_ist - IST_DELTA
print(f"Cuenta abierta: {account_time_ist} IST  =  {account_time_utc} UTC (guardado en MySQL)")

c.execute("INSERT INTO panel_conversions VALUES (?,?,?,?,?,?,?)",
          ('LEAD-MIDNIGHT', 'Test User', '919999999999', 'testuser01', 'acct01',
           account_time_utc.strftime('%Y-%m-%d %H:%M:%S'), account_time_utc.strftime('%Y-%m-%d %H:%M:%S')))

# También un lead con last_call_time en el mismo instante límite,
# para que funnel() tenga un total_touched > 0 y no divida por cero.
c.execute("INSERT INTO panel_leads VALUES (?,?,?,?,?,?,?,?,?,?,?)",
          ('LEAD-MIDNIGHT', 'Test User', '919999999999', 'India', 'hi', 'INTERESTED',
           'COMPLETED', 1, account_time_utc.strftime('%Y-%m-%d %H:%M:%S'), 180,
           account_time_utc.strftime('%Y-%m-%d %H:%M:%S')))
conn.commit()

print("\n" + "="*70)
print("TEST — La cuenta debe aparecer en 'Today' (07/08 IST), no en 'Yesterday'")
print("="*70)

s, e, label, ps, pe = resolve_range('today', ref=ref_ist)
print(f"  Rango 'today' calculado: {s} → {e}  ({label})")
check("el rango 'today' es el 7 de agosto IST", s.date() == datetime(2026,8,7).date())

conv_today = conversions_list(db, s, e, 10)
check("la cuenta aparece en 'Today'", len(conv_today) == 1,
      f"{len(conv_today)} cuentas encontradas")

fn_today = funnel(db, s, e)
check("funnel() cuenta la apertura en 'Today'", fn_today.get('accounts_opened') == 1,
      f"accounts_opened={fn_today.get('accounts_opened')}")

print("\n" + "="*70)
print("TEST — La cuenta NO debe aparecer en 'Yesterday' (06/08 IST)")
print("="*70)

sy, ey, labely, _, _ = resolve_range('yesterday', ref=ref_ist)
print(f"  Rango 'yesterday' calculado: {sy} → {ey}  ({labely})")
check("el rango 'yesterday' es el 6 de agosto IST", sy.date() == datetime(2026,8,6).date())

conv_yesterday = conversions_list(db, sy, ey, 10)
check("la cuenta NO aparece en 'Yesterday'", len(conv_yesterday) == 0,
      f"{len(conv_yesterday)} cuentas encontradas (debía ser 0)")

fn_yesterday = funnel(db, sy, ey)
check("funnel() no cuenta la apertura en 'Yesterday'", fn_yesterday.get('accounts_opened') == 0,
      f"accounts_opened={fn_yesterday.get('accounts_opened')}")

print("\n" + "="*70)
print("TEST — Caso de control: mismo bug pero con calldate del CDR")
print("="*70)

# Una llamada real a las 00:05 IST del 07/08 (fuera de la ventana de
# negocio 11am-7pm, pero puede pasar con pruebas manuales o retries).
call_ist = datetime(2026, 8, 7, 0, 5, 0)
call_utc = call_ist - IST_DELTA
c.execute("INSERT INTO cdr VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
          (call_utc.strftime('%Y-%m-%d %H:%M:%S'), '"Test"', '650098', '+919999999999',
           'from-elevenlabs', 'PJSIP/x', 'PJSIP/y', 'Dial', 'x', 45, 40, 'ANSWERED', 3, '', 'u1', ''))
conn.commit()

tr_today = traffic(db, s, e)
tr_yest  = traffic(db, sy, ey)
check("la llamada de las 00:05 IST cae en 'Today', no en 'Yesterday'",
      tr_today['total_calls'] == 1 and tr_yest['total_calls'] == 0,
      f"today={tr_today['total_calls']} yesterday={tr_yest['total_calls']}")

print("\n" + "="*70)
print("TEST — now_ist() y to_ist() son consistentes")
print("="*70)
n = now_ist()
back = to_ist(datetime.utcnow())
check("now_ist() y to_ist(utcnow()) coinciden dentro de 1 segundo",
      abs((n - back).total_seconds()) < 1)
check("to_ist(None) no rompe", to_ist(None) is None)
check("to_ist('') no rompe", to_ist('') is None)

print("\n" + "="*70)
if FAIL:
    print(f"❌ {len(FAIL)} PRUEBAS FALLARON:")
    for f in FAIL: print(f"   - {f}")
    sys.exit(1)
print("✅ EL BUG DE MEDIANOCHE IST ESTÁ REALMENTE CORREGIDO")
print("="*70)
conn.close()
