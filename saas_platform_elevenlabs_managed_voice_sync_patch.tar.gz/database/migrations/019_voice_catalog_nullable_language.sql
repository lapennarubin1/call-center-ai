-- 019_voice_catalog_nullable_language.sql
-- Segunda correccion estructural encontrada durante el testing de este
-- bloque (misma sesion que 018, mismo motivo de fondo, migracion
-- separada para mantener cada archivo con una sola causa documentada).
-- No modifica 001-018.
--
-- Problema real: voice_catalog.language quedo NOT NULL en 014. El punto
-- H de este bloque es explicito: "todos estos campos pueden ser NULL...
-- No inferir idioma por el nombre. No inventar locale." Una voz real de
-- ElevenLabs sin "labels.language" en la respuesta (ocurre — los labels
-- son opcionales y los pone quien sube la voz) no puede normalizarse sin
-- inventar un idioma que el proveedor nunca confirmo.
--
-- Se descubrio de la misma forma que 018: sync_voice_catalog() fallo con
-- "Column 'language' cannot be null" al procesar una voz de fixture sin
-- labels — caso realista, no un edge case forzado.
--
-- Impacto en el resto del sistema: modules/voice_ai usa su PROPIO
-- language (columna de agents, siempre requerido y validado contra
-- languages.py) para filtrar el catalogo publico — una voice_catalog
-- row con language NULL simplemente no matchea ningun filtro de idioma
-- explicito y no aparece en resultados filtrados, pero sigue existiendo
-- y sigue siendo seleccionable si el tenant la busca sin filtro. No
-- rompe validacion de compatibilidad agente<->voz (que ya es politica
-- conservadora: no bloquea por falta de dato, ver punto O).

ALTER TABLE voice_catalog
  MODIFY COLUMN language VARCHAR(10) NULL DEFAULT NULL;
