-- 018_voice_catalog_nullable_provider_multiplier.sql
-- Correccion estructural encontrada DURANTE el testing de este bloque
-- (sync real contra fixtures), no anticipada en el diseño original de
-- la migracion 014. No modifica 001-017.
--
-- Problema real: voice_catalog.provider_cost_multiplier quedo definida en
-- 014 como DECIMAL(6,3) NOT NULL DEFAULT 1.000. Este bloque (sincroniza-
-- cion real de ElevenLabs) exige explicitamente distinguir:
--   "unknown/standard" (la API no entrego el multiplicador para esa voz —
--   ocurre con la mayoria de las voces, el campo es opt-in via
--   include_custom_rates y ni asi esta garantizado en todas)
--   vs
--   "explicit 1.0" (la API confirmo que el multiplicador es exactamente 1.0)
-- Con NOT NULL DEFAULT 1.000 es estructuralmente imposible representar la
-- primera situacion sin mentir con un 1.0 que no fue confirmado por el
-- proveedor — exactamente lo que este bloque prohibe (punto L: "NO
-- inventar 1.0 por defecto como dato del proveedor").
--
-- Se descubrio al ejecutar sync_voice_catalog() contra datos de prueba
-- reales (fixtures) durante los tests de este mismo bloque: el INSERT
-- fallo con "Column 'provider_cost_multiplier' cannot be null" apenas se
-- proceso la primera voz sin custom_rate en la respuesta simulada — un
-- caso realista y esperado (la mayoria de las voces no lo traen).
--
-- customer_price_multiplier NO se toca: es NUESTRA configuracion de
-- pricing (no un dato del proveedor), tiene sentido que mantenga su
-- default de 1.0 porque es una decision de negocio nuestra, no una
-- afirmacion sobre lo que dice el proveedor.

ALTER TABLE voice_catalog
  MODIFY COLUMN provider_cost_multiplier DECIMAL(6,3) NULL DEFAULT NULL
  COMMENT 'INTERNO — NULL = proveedor no confirmo multiplicador (no es lo mismo que 1.0 explicito). Nunca se expone al tenant.';
