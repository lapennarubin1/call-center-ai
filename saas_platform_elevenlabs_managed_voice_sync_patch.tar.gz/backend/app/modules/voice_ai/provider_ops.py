"""Orquestacion sobre ai_provider_accounts: validar credencial,
sincronizar catalogo de voces, activar la cuenta EXPLICITAMENTE.

Ninguna funcion de este modulo:
  - actualiza wallet/ledger (separacion absoluta, punto Q del bloque)
  - crea o modifica un agente externo
  - genera TTS
  - dispara llamadas
  - activa una cuenta automaticamente solo porque el secreto existe

Todo el estado de sync/validacion se guarda en
ai_provider_accounts.settings (JSON ya existente desde la migracion 012)
y en voice_catalog.updated_at (ya autoactualiza) — NO hizo falta ninguna
migracion nueva para este bloque. Ver justificacion completa en el reporte
de entrega."""
import hashlib
import json
from datetime import datetime, timezone
from sqlalchemy import text

from .adapters import ElevenLabsVoiceAdapter
from .elevenlabs_http import ElevenLabsHTTPError
from ...core.integrations.secrets import resolve_secret


class ProviderOpsError(Exception):
    def __init__(self, reason: str):
        self.reason = reason
        super().__init__(reason)


def _get_account(session, account_id: int):
    row = session.execute(text("""
        SELECT id, provider_key, account_type, tenant_id, secret_ref, status, settings
        FROM ai_provider_accounts WHERE id=:id
    """), {"id": account_id}).mappings().first()
    if not row:
        raise ProviderOpsError("account_not_found")
    return row


def _merge_settings(session, account_id: int, patch: dict):
    """Merge superficial dentro de settings JSON — nunca borra otras
    claves ya presentes, nunca guarda el valor de un secreto ni un
    mensaje de error crudo (solo categorias seguras, ver ElevenLabsHTTPError)."""
    row = session.execute(text(
        "SELECT settings FROM ai_provider_accounts WHERE id=:id"
    ), {"id": account_id}).mappings().first()
    current = json.loads(row["settings"]) if row and row["settings"] else {}
    current.update(patch)
    session.execute(text(
        "UPDATE ai_provider_accounts SET settings=:s WHERE id=:id"
    ), {"s": json.dumps(current), "id": account_id})


def build_platform_voice_id(provider_key: str, provider_voice_id: str) -> str:
    """Deterministico, opaco, estable entre re-syncs: la MISMA voz del
    proveedor siempre produce el MISMO platform_voice_id — nunca se
    regenera. No reversible trivialmente al provider_voice_id (hash
    unidireccional), independiente del formato interno del proveedor."""
    digest = hashlib.sha256(f"{provider_key}:{provider_voice_id}".encode()).hexdigest()
    return f"v_{digest[:20]}"


def validate_provider_account(session, account_id: int) -> dict:
    """Read-only: confirma que la credencial de secret_ref funciona
    contra GET /v1/user. NUNCA cambia status — eso es exclusivo de
    activate_provider_account()."""
    account = _get_account(session, account_id)
    api_key = resolve_secret(account["secret_ref"])
    if not api_key:
        _merge_settings(session, account_id, {
            "last_validated_at": None, "last_validation_error": "credential_missing",
        })
        raise ProviderOpsError("credential_missing")

    from .elevenlabs_http import get as http_get
    try:
        user_info = http_get("/v1/user", api_key)
    except ElevenLabsHTTPError as e:
        _merge_settings(session, account_id, {
            "last_validated_at": datetime.now(timezone.utc).isoformat(),
            "last_validation_error": e.category,
        })
        raise ProviderOpsError(f"validation_failed:{e.category}") from None

    _merge_settings(session, account_id, {
        "last_validated_at": datetime.now(timezone.utc).isoformat(),
        "last_validation_error": None,
    })
    return {"ok": True, "user_id": user_info.get("user_id")}


def sync_voice_catalog(session, account_id: int) -> dict:
    """Sincroniza el catalogo REAL de voces de esta cuenta contra
    GET /v2/voices (paginado completo). Idempotente:
      - voz ya conocida (mismo provider_key+provider_voice_id) -> UPDATE
        de metadata, PRESERVA platform_voice_id.
      - voz nueva -> INSERT con platform_voice_id determinista.
      - voz que ya no aparece en esta corrida -> available=0 (NUNCA DELETE,
        para no romper agentes que ya la referencien)."""
    account = _get_account(session, account_id)
    adapter = ElevenLabsVoiceAdapter()
    provider_account = {"secret_ref": account["secret_ref"]}

    try:
        raw_voices = adapter.list_voices(provider_account)
    except ElevenLabsHTTPError as e:
        _merge_settings(session, account_id, {
            "last_sync_at": datetime.now(timezone.utc).isoformat(),
            "last_sync_status": "error", "last_sync_error": e.category,
        })
        raise ProviderOpsError(f"sync_failed:{e.category}") from None

    seen_ids, inserted, updated = [], 0, 0
    for raw in raw_voices:
        normalized = adapter.normalize_voice(raw)
        provider_voice_id = normalized.get("provider_voice_id")
        if not provider_voice_id:
            continue
        seen_ids.append(provider_voice_id)
        platform_voice_id = build_platform_voice_id(account["provider_key"], provider_voice_id)
        preview_url = raw.get("preview_url")  # solo se guarda internamente, nunca se expone via API

        existing_id = session.execute(text(
            "SELECT id FROM voice_catalog WHERE provider_key=:pk AND provider_voice_id=:pvid"
        ), {"pk": account["provider_key"], "pvid": provider_voice_id}).scalar()

        params = {
            "platform_voice_id": platform_voice_id, "provider_key": account["provider_key"],
            "provider_account_id": account_id, "provider_voice_id": provider_voice_id,
            "name": normalized.get("name") or provider_voice_id,
            "language": normalized.get("language"), "accent": normalized.get("accent"),
            "gender": normalized.get("gender"), "age": normalized.get("age"),
            "category": normalized.get("category"), "use_case": normalized.get("use_case"),
            "description": normalized.get("description"), "preview_url": preview_url,
            "provider_cost_multiplier": normalized.get("provider_cost_multiplier"),
        }
        if existing_id:
            session.execute(text("""
                UPDATE voice_catalog SET
                  name=:name, language=:language, accent=:accent, gender=:gender, age=:age,
                  category=:category, use_case=:use_case, description=:description,
                  preview_url=:preview_url, provider_cost_multiplier=:provider_cost_multiplier,
                  available=1
                WHERE id=:existing_id
            """), {**params, "existing_id": existing_id})
            updated += 1
        else:
            session.execute(text("""
                INSERT INTO voice_catalog
                  (platform_voice_id, provider_key, provider_account_id, provider_voice_id,
                   name, language, accent, gender, age, category, use_case, description,
                   preview_url, available, provider_cost_multiplier, customer_price_multiplier, pricing_tier)
                VALUES
                  (:platform_voice_id, :provider_key, :provider_account_id, :provider_voice_id,
                   :name, :language, :accent, :gender, :age, :category, :use_case, :description,
                   :preview_url, 1, :provider_cost_multiplier, 1.000, 'standard')
            """), params)
            inserted += 1

    if seen_ids:
        placeholders = ", ".join(f":pvid{i}" for i in range(len(seen_ids)))
        params2 = {f"pvid{i}": v for i, v in enumerate(seen_ids)}
        params2.update({"pk": account["provider_key"], "acc": account_id})
        session.execute(text(f"""
            UPDATE voice_catalog SET available=0
            WHERE provider_key=:pk AND provider_account_id=:acc
              AND provider_voice_id NOT IN ({placeholders})
        """), params2)

    _merge_settings(session, account_id, {
        "last_sync_at": datetime.now(timezone.utc).isoformat(),
        "last_sync_status": "ok", "last_sync_error": None,
        "last_sync_voice_count": len(raw_voices),
    })
    return {"ok": True, "inserted": inserted, "updated": updated, "total_seen": len(raw_voices)}


def activate_provider_account(session, account_id: int) -> dict:
    """Activacion EXPLICITA — nunca automatica por la sola presencia del
    env var. Exige, en orden estricto, que las 4 condiciones pasen:
      1) la cuenta existe
      2) el secreto existe (env var con valor real)
      3) validate_provider_account() exitoso (credencial funciona)
      4) sync_voice_catalog() exitoso (al menos una lectura de voces reales)
    Si CUALQUIER paso falla, status se queda en su valor actual — nunca
    hay una activacion parcial."""
    account = _get_account(session, account_id)
    if not resolve_secret(account["secret_ref"]):
        raise ProviderOpsError("credential_missing")

    validate_provider_account(session, account_id)
    sync_result = sync_voice_catalog(session, account_id)

    session.execute(text("UPDATE ai_provider_accounts SET status='active' WHERE id=:id"), {"id": account_id})
    _merge_settings(session, account_id, {"activated_at": datetime.now(timezone.utc).isoformat()})
    return {"ok": True, "status": "active", "voices_synced": sync_result["total_seen"]}
