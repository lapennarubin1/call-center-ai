"""Cliente HTTP real para la API de ElevenLabs (https://api.elevenlabs.io).

Solo transporte — sin logica de negocio. Responsabilidades:
  - timeout explicito en toda request (nunca requests sin timeout)
  - reintentos SOLO en errores transitorios (429, 502, 503, 504)
  - NUNCA reintenta 401/403/4xx de auth/permisos (reintentar no lo arregla)
  - header xi-api-key SIEMPRE server-side, nunca en query string/logs
  - User-Agent identificable interno
  - validacion defensiva de JSON
  - ninguna excepcion ni log de este modulo incluye jamas la api key

Requiere el paquete `requests` (agregado a requirements.txt en este
bloque — el proyecto no lo tenia como dependencia; se justifica porque
implementar reintentos/backoff correctos a mano sobre urllib crudo es mas
codigo y mas riesgo que usar la libreria estandar de facto del ecosistema
para esto).
"""
import logging
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

logger = logging.getLogger("elevenlabs_http")

BASE_URL = "https://api.elevenlabs.io"
USER_AGENT = "AIBusinessPlatform-Backend/1.0 (+internal; read-only sync)"
CONNECT_TIMEOUT = 5
READ_TIMEOUT = 15
MAX_PREVIEW_BYTES = 5_000_000  # 5MB — un preview de voz nunca deberia superar esto


class ElevenLabsHTTPError(Exception):
    """Error de transporte/HTTP. El mensaje y los atributos NUNCA
    incluyen la api key ni el header de autorizacion crudo."""

    def __init__(self, status_code, message: str, category: str):
        self.status_code = status_code
        self.category = category
        super().__init__(message)


def _session() -> requests.Session:
    s = requests.Session()
    retry = Retry(
        total=2,
        backoff_factor=1.0,
        status_forcelist=[429, 502, 503, 504],
        allowed_methods=["GET"],
        raise_on_status=False,
    )
    s.mount("https://", HTTPAdapter(max_retries=retry))
    return s


def get(path: str, api_key: str, params: dict | None = None) -> dict:
    """GET autenticado contra la API de ElevenLabs. Lanza
    ElevenLabsHTTPError con una categoria segura ante cualquier fallo —
    nunca expone la key en la excepcion ni en los logs."""
    url = f"{BASE_URL}{path}"
    headers = {"xi-api-key": api_key, "User-Agent": USER_AGENT, "Accept": "application/json"}
    try:
        resp = _session().get(url, headers=headers, params=params or {},
                               timeout=(CONNECT_TIMEOUT, READ_TIMEOUT))
    except requests.exceptions.Timeout:
        logger.warning("elevenlabs_http timeout path=%s", path)
        raise ElevenLabsHTTPError(None, "request timeout", "timeout") from None
    except requests.exceptions.RequestException:
        logger.warning("elevenlabs_http network_error path=%s", path)
        raise ElevenLabsHTTPError(None, "network error", "network_error") from None

    if resp.status_code == 401:
        raise ElevenLabsHTTPError(401, "invalid credential", "unauthorized")
    if resp.status_code == 403:
        raise ElevenLabsHTTPError(403, "insufficient permissions", "forbidden")
    if resp.status_code == 429:
        raise ElevenLabsHTTPError(429, "rate limited", "rate_limited")
    if resp.status_code >= 500:
        raise ElevenLabsHTTPError(resp.status_code, "provider server error", "provider_error")
    if resp.status_code >= 400:
        raise ElevenLabsHTTPError(resp.status_code, "request rejected", "client_error")

    try:
        return resp.json()
    except ValueError:
        raise ElevenLabsHTTPError(resp.status_code, "malformed JSON response", "malformed_response") from None


def get_binary(url: str, max_bytes: int = MAX_PREVIEW_BYTES) -> tuple[bytes, str]:
    """Descarga binaria SIN seguir redirects, con limite de tamano.

    IMPORTANTE: este cliente NO valida el host contra ningun allowlist —
    esa politica de seguridad (punto N: SSRF) vive en el llamador
    (routes.py), que debe validar el dominio ANTES de invocar esta
    funcion. Este modulo solo sabe hacer transporte."""
    headers = {"User-Agent": USER_AGENT}
    try:
        resp = _session().get(url, headers=headers, timeout=(CONNECT_TIMEOUT, READ_TIMEOUT),
                               stream=True, allow_redirects=False)
    except requests.exceptions.RequestException:
        raise ElevenLabsHTTPError(None, "preview fetch failed", "network_error") from None

    if resp.status_code in (301, 302, 303, 307, 308):
        raise ElevenLabsHTTPError(resp.status_code, "redirect not followed", "redirect_blocked")
    if resp.status_code != 200:
        raise ElevenLabsHTTPError(resp.status_code, "preview not available", "preview_unavailable")

    content_type = resp.headers.get("Content-Type", "application/octet-stream")
    chunks, total = [], 0
    for chunk in resp.iter_content(chunk_size=65536):
        total += len(chunk)
        if total > max_bytes:
            raise ElevenLabsHTTPError(None, "preview too large", "too_large")
        chunks.append(chunk)
    return b"".join(chunks), content_type
