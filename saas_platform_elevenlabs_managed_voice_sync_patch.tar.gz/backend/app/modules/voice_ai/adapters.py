"""Interfaces de adapters de proveedores + implementacion REAL de
ElevenLabsVoiceAdapter (punto Q del bloque anterior, ahora implementado).

ConversationProviderAdapter sigue siendo skeleton (create/update de agente
externo esta explicitamente fuera de alcance de este bloque). El adapter
de VOZ si hace requests reales — solo lectura, nunca escritura, nunca
genera audio.
"""
from abc import ABC, abstractmethod
from . import elevenlabs_http as http


class ConversationProviderAdapter(ABC):
    """Contrato para un motor de conversacion. Sin implementacion real
    todavia — create/update de agentes externos es un bloque futuro."""

    @abstractmethod
    def list_agents(self, provider_account) -> list[dict]: ...

    @abstractmethod
    def create_agent(self, provider_account, config: dict) -> dict: ...

    @abstractmethod
    def update_agent(self, provider_account, external_agent_id: str, config: dict) -> dict: ...

    @abstractmethod
    def get_agent(self, provider_account, external_agent_id: str) -> dict: ...

    @abstractmethod
    def capabilities(self) -> dict: ...


class VoiceProviderAdapter(ABC):
    @abstractmethod
    def list_voices(self, provider_account, filters: dict | None = None) -> list[dict]: ...

    @abstractmethod
    def get_voice(self, provider_account, provider_voice_id: str) -> dict: ...

    @abstractmethod
    def normalize_voice(self, raw: dict) -> dict: ...

    @abstractmethod
    def get_preview_url(self, provider_account, provider_voice_id: str) -> str | None: ...

    @abstractmethod
    def capabilities(self) -> dict: ...


def _resolve_api_key(provider_account: dict) -> str:
    from ...core.integrations.secrets import resolve_secret
    api_key = resolve_secret(provider_account["secret_ref"])
    if not api_key:
        raise RuntimeError("credential_missing")
    return api_key


class ElevenLabsVoiceAdapter(VoiceProviderAdapter):
    """Adapter REAL — hace requests de solo lectura contra
    https://api.elevenlabs.io. Nunca escribe, nunca genera TTS, nunca crea
    ni modifica un agente conversacional."""

    def list_voices(self, provider_account: dict, filters: dict | None = None) -> list[dict]:
        """Pagina el catalogo COMPLETO via /v2/voices usando has_more +
        next_page_token (nunca asume que la primera pagina alcanza).
        include_custom_rates=true para pedir el multiplicador de creditos
        cuando la API lo tenga disponible — no todas las voces lo traen."""
        api_key = _resolve_api_key(provider_account)
        params = {"page_size": 100, "include_custom_rates": "true"}
        if filters:
            params.update(filters)

        all_voices: list[dict] = []
        next_token = None
        while True:
            if next_token:
                params["next_page_token"] = next_token
            data = http.get("/v2/voices", api_key, params=params)
            all_voices.extend(data.get("voices") or [])
            if not data.get("has_more"):
                break
            next_token = data.get("next_page_token")
            if not next_token:
                break
        return all_voices

    def get_voice(self, provider_account: dict, provider_voice_id: str) -> dict:
        api_key = _resolve_api_key(provider_account)
        return http.get(f"/v1/voices/{provider_voice_id}", api_key)

    def get_preview_url(self, provider_account: dict, provider_voice_id: str) -> str | None:
        """Devuelve la preview_url CRUDA del proveedor — de uso INTERNO
        exclusivamente. El llamador (routes.py) es responsable de validar
        el host contra el allowlist antes de descargarla; este metodo no
        hace streaming ni descarga nada, solo resuelve la URL."""
        voice = self.get_voice(provider_account, provider_voice_id)
        return voice.get("preview_url")

    def capabilities(self) -> dict:
        return {
            "list_voices": True, "preview": True, "pagination": True,
            "credit_multiplier": "opt-in via include_custom_rates, no garantizado para toda voz",
        }

    def normalize_voice(self, raw: dict) -> dict:
        """raw: un elemento de voices[] de GET /v2/voices o el resultado
        de GET /v1/voices/{id}. Tolera CUALQUIER campo ausente -> None.
        Nunca infiere gender/accent/language por el nombre de la voz.
        Nunca inventa un locale. provider_cost_multiplier queda None si
        la API no lo entrego — nunca se asume 1.0 (punto L)."""
        labels = raw.get("labels") or {}
        return {
            "provider_voice_id": raw.get("voice_id"),
            "name": raw.get("name"),
            "language": labels.get("language"),
            "accent": labels.get("accent"),
            "gender": labels.get("gender"),
            "age": labels.get("age"),
            "category": raw.get("category"),
            "use_case": labels.get("use_case") or labels.get("use case") or labels.get("usecase"),
            "description": raw.get("description"),
            "has_preview": bool(raw.get("preview_url")),
            "provider_cost_multiplier": _extract_cost_multiplier(raw),
        }


def _extract_cost_multiplier(raw: dict):
    """El nombre exacto del campo de multiplicador de creditos no esta
    100% confirmado en la documentacion publica al momento de este
    bloque — se intenta con las claves mas plausibles segun la
    convencion de nombres de la API (custom_rate, dado que el parametro
    de request se llama include_custom_rates) y se degrada a None sin
    fallar si ninguna esta presente. NUNCA se defaultea a 1.0."""
    rate = raw.get("custom_rate")
    if rate is None:
        rate = raw.get("credit_multiplier")
    if rate is None:
        return None
    if isinstance(rate, dict):
        return rate.get("multiplier") or rate.get("value")
    return rate
