"""Comandos operativos. Uso (dentro del contenedor o con el venv):
  flask --app app create-tenant     # crea el tenant inicial + owner desde SAAS_INITIAL_* del .env
  flask --app app enable-module --tenant <slug> --module crm
"""
import os
import click
from flask import current_app
from sqlalchemy import text
from werkzeug.security import generate_password_hash
from .db import saas_session

SPRINT1_MODULES = ("voice_ai", "crm")


def register_cli(app):
    @app.cli.command("create-tenant")
    @click.option("--slug", default=lambda: os.getenv("SAAS_INITIAL_TENANT_SLUG"))
    @click.option("--name", default=lambda: os.getenv("SAAS_INITIAL_TENANT_NAME"))
    @click.option("--admin-user", default=lambda: os.getenv("SAAS_INITIAL_ADMIN_USER"))
    @click.option("--admin-pass", default=lambda: os.getenv("SAAS_INITIAL_ADMIN_PASS"))
    @click.option("--plan", default="internal-unlimited")
    @click.option("--tenant-id", type=int, default=None,
                  help="Forzar id (ej. 1 para alinear con asterisk.tenants id=1 de Fase 0)")
    def create_tenant(slug, name, admin_user, admin_pass, plan, tenant_id):
        if not all([slug, name, admin_user, admin_pass]):
            raise click.ClickException("Faltan slug/name/admin-user/admin-pass (o SAAS_INITIAL_* en .env)")
        with saas_session() as s:
            plan_id = s.execute(text("SELECT id FROM plans WHERE slug=:p"), {"p": plan}).scalar()
            if not plan_id:
                raise click.ClickException(f"Plan '{plan}' no existe (¿se aplicaron las migraciones?)")
            if s.execute(text("SELECT 1 FROM tenants WHERE slug=:s"), {"s": slug}).first():
                raise click.ClickException(f"El tenant '{slug}' ya existe")
            if tenant_id:
                s.execute(text("INSERT INTO tenants (id, slug, name, plan_id) VALUES (:i, :s, :n, :p)"),
                          {"i": tenant_id, "s": slug, "n": name, "p": plan_id})
                tid = tenant_id
            else:
                tid = s.execute(text("INSERT INTO tenants (slug, name, plan_id) VALUES (:s, :n, :p)"),
                                {"s": slug, "n": name, "p": plan_id}).lastrowid
            s.execute(text("INSERT INTO subscriptions (tenant_id, plan_id, status) VALUES (:t, :p, 'active')"),
                      {"t": tid, "p": plan_id})
            s.execute(text("INSERT INTO users (tenant_id, username, password_hash, role) VALUES (:t, :u, :h, 'owner')"),
                      {"t": tid, "u": admin_user, "h": generate_password_hash(admin_pass)})
            for m in SPRINT1_MODULES:
                s.execute(text("INSERT IGNORE INTO tenant_modules (tenant_id, module_key) VALUES (:t, :m)"), {"t": tid, "m": m})
        click.echo(f"OK tenant id={tid} slug={slug} owner={admin_user} modulos={','.join(SPRINT1_MODULES)}")

    @app.cli.command("enable-module")
    @click.option("--tenant", required=True, help="slug del tenant")
    @click.option("--module", "module_key", required=True)
    @click.option("--disable", is_flag=True)
    def enable_module(tenant, module_key, disable):
        from .core.registry import MODULES
        if module_key not in MODULES:
            raise click.ClickException(f"Modulo desconocido: {module_key}. Disponibles: {', '.join(MODULES)}")
        status = "disabled" if disable else "enabled"
        with saas_session() as s:
            tid = s.execute(text("SELECT id FROM tenants WHERE slug=:s"), {"s": tenant}).scalar()
            if not tid:
                raise click.ClickException("Tenant no encontrado")
            s.execute(text("""INSERT INTO tenant_modules (tenant_id, module_key, status) VALUES (:t, :m, :st)
                              ON DUPLICATE KEY UPDATE status=:st"""), {"t": tid, "m": module_key, "st": status})
        click.echo(f"OK {module_key} -> {status} para {tenant}")

    @app.cli.command("provider-validate")
    @click.option("--account-id", required=True, type=int)
    def provider_validate(account_id):
        """Valida (read-only) la credencial de una ai_provider_accounts
        contra GET /v1/user. NUNCA imprime la key. Exit code != 0 si falla."""
        from .modules.voice_ai.provider_ops import validate_provider_account, ProviderOpsError
        with saas_session() as s:
            try:
                result = validate_provider_account(s, account_id)
            except ProviderOpsError as e:
                raise click.ClickException(f"Validacion fallida: {e.reason}")
        click.echo(f"OK credencial valida. user_id={result['user_id']}")

    @app.cli.command("provider-sync-voices")
    @click.option("--account-id", required=True, type=int)
    def provider_sync_voices(account_id):
        """Sincroniza el catalogo de voces (solo lectura contra el
        proveedor). No activa la cuenta. Exit code != 0 si falla."""
        from .modules.voice_ai.provider_ops import sync_voice_catalog, ProviderOpsError
        with saas_session() as s:
            try:
                result = sync_voice_catalog(s, account_id)
            except ProviderOpsError as e:
                raise click.ClickException(f"Sync fallido: {e.reason}")
        click.echo(f"OK sync completo. nuevas={result['inserted']} actualizadas={result['updated']} total_vistas={result['total_seen']}")

    @app.cli.command("provider-activate")
    @click.option("--account-id", required=True, type=int)
    @click.confirmation_option(prompt="Esto va a activar la cuenta de proveedor para uso real. ¿Confirmar?")
    def provider_activate(account_id):
        """Activacion EXPLICITA — exige validate + sync exitosos antes de
        poner status='active'. Sin activacion parcial. Exit code != 0 si
        cualquier paso falla (la cuenta queda en su status actual)."""
        from .modules.voice_ai.provider_ops import activate_provider_account, ProviderOpsError
        with saas_session() as s:
            try:
                result = activate_provider_account(s, account_id)
            except ProviderOpsError as e:
                raise click.ClickException(f"Activacion fallida (cuenta NO activada): {e.reason}")
        click.echo(f"OK cuenta {account_id} -> status=active. Voces sincronizadas: {result['voices_synced']}")
